import Data.Char

isTriple :: Int -> Int -> Int -> Bool
isTriple a b c = a * a + b * b == c * c

isTripleAny :: Int -> Int -> Int -> Bool
isTripleAny a b c 
  | a * a + b * b == c * c = True
  | a * a + c * c == b * b = True
  | b * b + c * c == a * a = True
  | otherwise = False

halfEvens :: [Int] -> [Int]
halfEvens [] = []
halfEvens (x:xs)
  | x `mod` 2 == 0 = x `div` 2 : halfEvens xs
  | otherwise = x : halfEvens xs

inRange :: Int -> Int -> [Int] -> [Int]
inRange _ _ [] = []
inRange a b (x:xs)
  | x >= a && x <= b = x : inRange a b xs
  | otherwise = inRange a b xs

countPositives :: [Int] -> Int
countPositives [] = 0
countPositives (x:xs)
  | x > 0 = 1 + countPositives xs
  | otherwise = countPositives xs

capitalised :: String -> String
capitalised [] = ""
capitalised (x:xs) = toUpper x : map toLower xs

letterCount :: String -> Int
letterCount [] = 0
letterCount (x:xs) = 1 + letterCount xs

checkTitle :: [String] -> [String]
checkTitle [] = []
checkTitle (x:xs)
  | letterCount x >= 4 = capitalised x : checkTitle xs
  | otherwise = map toLower x : checkTitle xs

title :: [String] -> [String]
title [] = []
title (x:xs) = capitalised x : checkTitle xs