{- DO NOT CHANGE MODULE NAME, if you do, the file will not load properly -}
module Coursework where

import Data.List
import qualified Data.Set as HS (fromList, toList, union, insert, difference, member, map, foldr, intersection, delete, size, powerSet, empty, null, singleton)
import Test.QuickCheck

{-
  Your task is to design a datatype that represents the mathematical concept of
  a (finite) set of elements (of the same type). We have provided you with an
  interface (do not change this!) but you will need to design the datatype and
  also support the required functions over sets. Any functions you write should
  maintain the following invariant: no duplication of set elements.

  There are lots of different ways to implement a set. The easiest is to use a
  list. Alternatively, one could use an algebraic data type, wrap a binary
  search tree, or even use a self-balancing binary search tree. Extra marks will
  be awarded for efficient implementations (a self-balancing tree will be more
  efficient than a linked list for example).

  You are **NOT** allowed to import anything from the standard library or other
  libraries. Your edit of this file should be completely self-contained.

  **DO NOT** change the type signatures of the functions below: if you do, we
  will not be able to test them and you will get 0% for that part. While sets
  are unordered collections, we have included the Ord constraint on some
  signatures: this is to make testing easier.

  You may write as many auxiliary functions as you need. Everything must be in
  this file.

  See the note **ON MARKING** at the end of the file.
-}

{-
   PART 1.
   You need to define a Set datatype.
-}

-- you **MUST** change this to your own data type. The declaration of Set a =
-- Int is just to allow you to load the file into ghci without an error, it
-- cannot be used to represent a set.

--THIS IS A BINARY TREE WITH THE NAME SET, IT RECURSES ITSELF AND IS NOT SELF BALANCING. 
data Set a =
  Empty
  | Node (Set a) a (Set a)
  deriving (Show)

{-
   PART 2.
   If you do nothing else, you must get the toList, fromList and equality working. If they
   do not work properly, it is impossible to test your other functions, and you
   will fail the coursework!
-}

-- toList {2,1,4,3} => [1,2,3,4]
-- the output must be sorted.
toList :: (Ord a) => Set a -> [a]
toList Empty = []
toList (Node left a right) =
  toList left ++ [a] ++ toList right

--QUICKSORT SORTS OUT THE LIST AND IT ALSO REMOVES DUPLICATES
quicksort :: (Ord a) => [a] -> [a]
quicksort [] = []
quicksort (x:xs) = (quicksort $ filter (< x) xs) ++ [x] ++ (quicksort $ filter (> x) xs)

toBT :: [a] -> Set a
toBT [] = Empty
toBT xs = Node (toBT left) (x) (toBT right)
  where
    middle = length xs `div` 2
    (left, x:right) = splitAt middle xs

-- fromList: do not forget to remove duplicates!
fromList :: Ord a => [a] -> Set a
fromList [] = Empty
fromList xs = toBT (quicksort xs)

-- Make sure you satisfy this property. If it fails, then all of the functions
-- on Part 3 will also fail their tests
toFromListProp :: IO ()
toFromListProp =
  quickCheck
    ((\xs -> (HS.toList . HS.fromList $ xs) == (toList . fromList $ xs)) :: [Int] -> Bool)

-- test if two sets have the same elements (pointwise equivalent).
instance (Ord a) => Eq (Set a) where
  s1 == s2 = toList(s1) == toList(s2)

-- you should be able to satisfy this property quite easily
eqProp :: IO ()
eqProp =
  quickCheck ((\xs -> (fromList . toList . fromList $ xs) == fromList xs) :: [Char] -> Bool)

{-
   PART 3. Your Set should contain the following functions. DO NOT CHANGE THE
   TYPE SIGNATURES.
-}

-- the empty set
empty :: Set a
empty = Empty

-- is it the empty set?
null :: Set a -> Bool
null (Empty) = True
null s = False

-- build a one element Set
singleton :: a -> Set a
singleton x = Node (Empty) x (Empty)

-- insert an element *x* of type *a* into Set *s* make sure there are no
-- duplicates!
insert :: (Ord a) => a -> Set a -> Set a
insert x Empty =  Coursework.singleton x
insert x (Node left value right)
  | x < value = Node (Coursework.insert x left) value right
  | x > value = Node left value (Coursework.insert x right)
  | otherwise = Node left value right
--test done
insertProp :: Int -> [Int] -> Bool
insertProp x xs = Coursework.insert x (fromList xs) == fromList (x : xs)


-- join two Sets together be careful not to introduce duplicates.
union :: (Ord a) => Set a -> Set a -> Set a
union Empty s2 = s2
union s1 Empty = s1
union s1 s2 = fromList (toList s1 ++ toList s2)
--test done
unionProp :: [Int] -> [Int] -> Bool
unionProp xs ys = Coursework.union (fromList xs) (fromList ys) == fromList (xs ++ ys)

-- return, as a Set, the common elements between two Sets
intersection :: (Ord a) => Set a -> Set a -> Set a
intersection s1 Empty = Empty
intersection Empty s2 = Empty
intersection (Node left value right) s2
  | member value s2 = Node (intersection left s2) value (intersection right s2)
  | otherwise = Coursework.union (intersection left s2) (intersection right s2)

testintersection :: [Int] -> [Int] -> Bool
testintersection xs ys =
  toList(intersection (fromList xs) (fromList ys)) == HS.toList(HS.intersection (HS.fromList xs) (HS.fromList ys))


-- all the elements in *s1* not in *s2*
-- {1,2,3,4} `difference` {3,4} => {1,2}
-- {} `difference` {0} => {}
difference :: (Ord a) => Set a -> Set a -> Set a
difference Empty _ = Empty
difference s1 Empty = s1
difference (Node left value right) s2
  | member value s2 = Coursework.union (difference left s2) (difference right s2)
  | otherwise = Node (difference left s2) value (difference right s2)
--test
differenceProp :: [Int] -> [Int] -> Bool
differenceProp xs ys = toList (difference (fromList xs) (fromList ys)) == HS.toList (HS.difference (HS.fromList xs) (HS.fromList ys))

-- is element *x* in the Set s1?
member :: (Ord a) => a -> Set a -> Bool
member x Empty = False
member x (Node left value right)
  | x > value = member x right
  | x < value = member x left
  | x == value = True
--test
memberProp :: Int -> [Int] -> Bool
memberProp x xs = Coursework.member x (fromList xs) == elem x xs


-- how many elements are there in the Set?
cardinality :: Set a -> Int
cardinality Empty = 0
cardinality (Node left value right) = 1 + cardinality left + cardinality right
--test THIS TEST HAS AN ISSUE BECAUSE THE SET DONT HAVE DUPLICATES
cardinalityProp :: [Int] -> Bool
cardinalityProp xs = Coursework.cardinality (fromList xs) == length (removeDuplicates xs)

-- apply a function to every element in the Set
setmap :: (Ord b) => (a -> b) -> Set a -> Set b
setmap _ Empty = Empty
setmap f (Node left value right) = Node (setmap f left) (f value) (setmap f right)
--test
setmapProp :: [Int] -> Bool
setmapProp xs = Coursework.setmap (* 2) (fromList xs) == fromList (map (* 2) (toList (fromList xs)))

-- right fold a Set using a function *f*  
setfoldr :: (a -> b -> b) -> Set a -> b -> b
setfoldr _ Empty acc = acc
setfoldr f (Node left value right) acc = setfoldr f left (f value (setfoldr f right acc))
--test
prop_setfoldr :: [Int] -> Bool
prop_setfoldr xs = Coursework.setfoldr (+) (fromListNoOrd xs) 0 == foldr (+) 0 xs

toListNoOrd :: Set a -> [a]
toListNoOrd Empty = []
toListNoOrd (Node left a right) =
  toListNoOrd left ++ [a] ++ toListNoOrd right

fromListNoOrd :: [a] -> Set a
fromListNoOrd [] = Empty
fromListNoOrd xs = toBT (xs)

-- remove an element *x* from the set
-- return the set unaltered if *x* is not present
removeSet :: (Eq a) => a -> Set a -> Set a
removeSet _ Empty = Empty
removeSet x s2 = toBT (filter (/= x) (removeDuplicates(toListNoOrd s2)))

removeDuplicates :: (Eq a) => [a] -> [a]
removeDuplicates [] = []
removeDuplicates (x:xs) = x : removeDuplicates (filter (/= x) xs)

--test
prop_removeSet :: Int -> [Int] -> Bool
prop_removeSet x s = insertionSort (toListNoOrd (removeSet x (fromListNoOrd s))) == HS.toList(HS.delete x (HS.fromList s))

insertionSort :: (Ord a) => [a] -> [a]
insertionSort = foldr insertr []

insertr :: (Ord a) => a -> [a] -> [a]
insertr x [] = [x]
insertr x (y:ys)
  | x <= y    = x : y : ys
  | otherwise = y : insertr x ys

powerSetList :: [a] -> [[a]]
powerSetList [] = [[]]
powerSetList (x:xs) = let y = y ++ powerSetList xs in map (x:) y

-- powerset of a set
-- powerset {1,2} => { {}, {1}, {2}, {1,2} }
powerSet :: Set a -> Set (Set a)
powerSet s = fromListNoOrd (map (fromListNoOrd) (powerSetList (toListNoOrd s)))

proppowerset :: [Int] -> Bool
proppowerset xs =
  HS.size (HS.powerSet set) == cardinality (powerSet (fromList xs)) where set = HS.fromList xs

main :: IO()
main = quickCheck prop_removeSet

{-
   ON MARKING:

   Be careful! This coursework will be marked using QuickCheck, against
   Haskell's own Data.Set implementation. This testing will be conducted
   automatically via a marking script that tests for equivalence between your
   output and Data.Set's output. There is no room for discussion, a failing test
   means that your function does not work properly: you do not know better than
   QuickCheck and Data.Set! Even one failing test means 0 marks for that
   function. Changing the interface by renaming functions, deleting functions,
   or changing the type of a function will cause the script to fail to load in
   the test harness. This requires manual adjustment by a TA: each manual
   adjustment will lose 10% from your score. If you do not want to/cannot
   implement a function, leave it as it is in the file (with undefined).

   Marks will be lost for too much similarity to the Data.Set implementation.

   Pass: creating the Set type and implementing toList and fromList is enough
   for a passing mark of 40%, as long as both toList and fromList satisfy the
   toFromListProp function.

   The maximum mark for those who use Haskell lists to represent a Set is 70%.
   To achieve a higher grade than is, one must write a more efficient
   implementation. 100% is reserved for those brave few who write their own
   self-balancing binary tree.
-}
