squareList :: [Int] -> [Int]
squareList [] = []
squareList (n:ns) = n*n : squareList ns

returnSquare :: [Int] -> Int
returnSquare [] = 0
returnSquare (n:ns) = n*n + returnSquare ns

checkList :: [Int] -> Bool
checkList [] = True
checkList (n:ns)
    | n >= 0 = checkList ns
    | otherwise = False

f :: Int -> Int
f a = a + 1

minValue :: (Int -> Int) -> Int -> Int
minValue f n = minimum (map f [0..n])