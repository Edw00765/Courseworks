struct file{
    char filename[100];
    char date[20];
    int size;
};

struct file* pointfile1(struct file *file, const char* filename, const char* date, int size){
    strncpy(file -> filename, filename, sizeof(file -> filename));
    strncpy(file -> date, date, sizeof(file -> date));
    file -> size = size;
    return file;
};


int main() {
    struct file file1;

    printf(pointfile1(&file1, "example.txt", "2024-04-22", 1024));

    // Access the modified struct file
    printf("File Name: %s\n", file1.filename);
    printf("Date Created: %s\n", file1.date);
    printf("Byte Size: %d\n", file1.size);

    return 0;
}