merge :: [Int] -> [Int] -> [Int]
merge xs [] = xs
merge [] xs = xs
merge (x:xs) (y:ys)
    | x <= y = x : merge xs (y:ys)
    | otherwise = y : merge (x:xs) ys

foldr2 :: (a -> b -> b) -> b -> [a] -> b
foldr2 _ x [] = x
foldr2 f x (y:ys) = f y (foldr f x ys)

smallestSquare :: Int
smallestSquare = head [x | x <- [1..], x*x > 1000000]

divides :: Int -> Int -> Bool
divides 0 _ = False
divides x y 
    | mod y x == 0 = True
    | otherwise = False

prime :: Int -> Bool
prime x
    | x <= 1 = False
    | x <= 2 = True
    | otherwise = foldr1 (&&) [not (divides a x) | a <- [x-1, x-2..2]]

mySum :: Num a => [a] -> a
mySum [] = 0;
mySum xs = foldr (+) 0 (map cube xs)

cube :: Num a => a -> a
cube a = a * a * a

sumAcc :: [Int] -> Int -> Int
sumAcc [] acc = acc
sumAcc (x:xs) acc = sumAcc xs (acc + x)

