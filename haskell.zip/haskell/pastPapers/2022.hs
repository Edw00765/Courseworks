smallestSquare :: [Int] -> Int
smallestSquare [] = 0
smallestSquare xs = head [x | x <- xs, x*x > 1000000]

divides :: Int -> Int -> Bool
divides 0 _ = False
divides a b 
    | mod b a == 0 = True
    | otherwise = False

prime :: Int -> Bool
prime x
    | x <= 1 = False
    | x == 2 = True
    | otherwise = foldr1 (&&) [not (divides a x) | a <- [x-1, x-2..2]]

{-foldr1 :: (a -> a -> a) -> [a] -> a
foldr1 _ [] = error "foldr1: empty list"
foldr1 f [x] = x
foldr1 f [x:xs] = f x (foldr1 f xs)-}

allLow ::[Char] -> Bool
allLow [] = True
allLow xs = foldr1 (&&) [elem x ['a'..'z'] | x <- xs]

merge :: [Int] -> [Int] -> [Int]
merge [] xs = xs
merge xs [] = xs
merge (x:xs) (y:ys)
    | x <= y = x : merge xs (y:ys)
    | x > y = y : merge (x:xs) ys

mSort :: [Int] -> [Int]
mSort [] = []
mSort (x:xs) = merge [x] (mSort xs)

insert :: Ord a => a -> [a] -> [a]
insert x [] = [x]
insert x (y:ys)
    | x <= y = x : (y:ys)
    | otherwise = y : insert x ys

iSort :: Ord a => [a] -> [a]
iSort [] = []
iSort xs = reverse (iSort' xs)

iSort' :: Ord a => [a] -> [a]
iSort' [] = []
iSort' (x:xs) = insert x (iSort' xs)

zip1 :: [a] -> [b] -> [(a, b)]
zip1 _ [] = []
zip1 [] _ = []
zip1 (x:xs) (y:ys) = (x, y) : zip1 xs ys

unzip1 :: [(a,b)] -> ([a], [b])
unzip1 [] = ([], [])
unzip1 ((x,y):xys) =
    let (xs, ys) = unzip1 xys
    in (x:xs, y:ys)

inverseUnzip :: ([a], [b]) -> [(a,b)]
inverseUnzip (_, []) = []
inverseUnzip ([], _) = []
inverseUnzip (xs, ys) = zip1 xs ys

divTail :: Int -> Int -> Int -> Int
divTail acc n m 
    | n < m = acc
    | otherwise = divTail (acc + 1) (n - m) m

