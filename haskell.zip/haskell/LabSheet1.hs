-- square :: Int -> Int
square a = a * a


pyth a b = square a + square b

isTriple :: Int -> Int -> Int -> Bool
isTriple a b c = pyth a b == square c

isTripleAny :: Int -> Int -> Int -> Bool
isTripleAny a b c = (isTriple a b c) || (isTriple b a c) || (isTriple c b a)

halveEvens :: [Int] -> [Int]
halveEvens xs = [if x `mod` 2 == 0 then x `div` 2 else x | x <- xs]

inRange :: Int -> Int -> [Int] -> [Int]
inRange lo hi xs = [x | x <- xs, lo <= x, x <= hi]

countPositives :: [Int] -> Int
countPositives list = length [x | x <- list, x > 0]

capitalised :: String -> String
capitalised [] = []
capitalised (x:xs) = toUpper x : [toLower x | x <- xs]

capitaliseLong :: String -> String
capitaliseLong word = if (length word >= 4) then (capitalised word)
                       else (lowercase word)

lowercase :: String -> String
lowercase xs = [toLower x | x <- xs]

title :: [String] -> [String]
title [] = []
title (w:words) = capitalised w : [capitaliseLong w | w <- words]