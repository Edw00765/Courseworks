import Data.Char

inRange :: Int -> Int -> [Int] -> [Int]
inRange _ _ [] = []
inRange a b (x:xs)
  | x >= a && x <= b = x : inRange a b xs
  | otherwise = inRange a b xs

countPositives :: [Int] -> Int
countPositives [] = 0
countPositives (x:xs)
  | x > 0 = 1 + countPositives xs
  | otherwise = countPositives xs

capitalised :: String -> String
capitalised [] = ""
capitalised (x:xs) = toUpper x : map toLower xs

letterCount :: String -> Int
letterCount [] = 0
letterCount (x:xs) = 1 + letterCount xs

checkTitle :: [String] -> [String]
checkTitle [] = []
checkTitle (x:xs)
  | letterCount x >= 4 = capitalised x : checkTitle xs
  | otherwise = map toLower x : checkTitle xs

title :: [String] -> [String]
title [] = []
title (x:xs) = capitalised x : checkTitle xs

insert :: Ord a => a -> [a] -> [a]
insert x [] = [x]
insert x (y:ys)
  | x <= y    = x : y : ys
  | otherwise = y : insert x ys

isort :: Ord a => [a] -> [a]
isort [] = []
isort (x:xs) = insert x (isort xs)

merge :: Ord a => [a] -> [a] -> [a]
merge [] ys = ys
merge xs [] = xs
merge (x:xs) (y:ys)
  | x <= y = x : merge xs (y:ys)
  | otherwise = y : merge (x:xs) ys

rotor :: Int -> String -> String
rotor _ "" = ""
rotor x (y:ys)
  | x < 0 || x > length ys = error "The offset number is less than 0 or greater than the string given"
  | otherwise = drop (x-1) ys ++ take (x-1) ys

makeKey :: Int -> [(Char,Char)]
makeKey offset
  | offset < 0 || offset > 25 = error "Invalid offset. Must be between 0 and 25."
  | otherwise = zip alphabet (rotor offset alphabet)
  where
    alphabet = ['A'..'Z']

lookUp :: Char -> [(Char,Char)] -> (Char, Char)
lookUp _ [] = error "key not found"
lookUp a ((k, v):xs)
  | k == a    = (k, v)
  | otherwise = lookUp a xs

encipher :: Int -> Char -> Char
encipher offset y
  | y == ' ' = ' '
  | offset < 0 || offset > 25 = error "Invalid offset. Must be between 0 and 25."
  | otherwise = snd (lookUp y (makeKey offset))

normalise :: String -> String
normalise "" = ""
normalise (x:xs)
  | x /= ' ' = (toUpper x) : normalise xs
  | otherwise = normalise xs

encipherStr :: Int -> String -> String
encipherStr offset ys = map (\y -> encipher offset y) (normalise ys)