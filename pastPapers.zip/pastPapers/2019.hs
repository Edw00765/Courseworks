import Debug.Trace
pythagoreanTriple :: [[Int]]
pythagoreanTriple = [[x,y,z] | x <- [1..20], y <- [x..20], z <- [y..20], x*x + y*y == z*z,  x * y `div` 2 > 100]


merge :: Ord a => [a] -> [a] -> [a]
merge xs [] = xs
merge [] xs = xs
merge (x:xs) (y:ys)
    | x <= y = x : merge xs (y:ys)
    | otherwise = y : merge (x:xs) ys

swap :: (a -> b) -> (b -> c) -> a -> c
swap f g x= g (f x)

allOdd :: [Int] -> Bool
allOdd xs = all odd xs

data Tree a = Nil | Node a (Tree a) (Tree a) deriving (Eq, Ord, Show, Read)

depth :: Tree a -> Int
depth Nil = 0
depth (Node _ left right) = 1 + max (depth left) (depth right)

stupid :: IO ()
stupid = do
    input <- getLine
    let num = read input :: Int
    loop num
    where
        loop 0 = return ()
        loop n = do
            putStrLn "Stupid!"
            loop (n-1)

lmt :: Num a => [a] -> a -> a
lmt [] acc = acc
lmt (n:ns) acc = lmt ns (n * acc)