merge :: [Int] -> [Int] -> [Int]
merge [] ys = ys
merge xs [] = xs
merge (x:xs) (y:ys)
    | x < y = x : merge xs (y:ys)
    | otherwise = y : merge (x:xs) ys

foldr2 :: (a -> b -> b) -> b -> [a] -> b
foldr2 f acc [] = acc
foldr2 f acc (x:xs) = f x (foldr2 f acc xs)

smallestSquare :: Int
smallestSquare = head [x | x<-[1..], x*x >1000000]

divides :: Int -> Int -> Bool
divides a b
    | b `mod` a == 0 = True
    | otherwise = False

prime :: Int -> Bool
prime n
    | n < 2 = False
    | otherwise = foldr1 (&&) [not x | x <- [divides y n | y <- [2..n-1]]]


cuber :: Num a => a -> a
cuber n = n*n*n

mySum :: Num a => [a] -> a
mySum [] = 0
mySum xs = foldr (+) 0 [cuber x | x <- xs]

sumAcc :: Num a => [a] -> a -> a
sumAcc [] acc = acc
sumAcc (x:xs) acc = sumAcc xs (acc + x)

test1 :: (Num a, Eq a) => [a] -> Bool
test1 xs = sumAcc xs 0 == sum xs

test2 :: (Num a, Eq a)=> [a] -> [a] -> Bool
test2 xs ys = sumAcc(xs ++ ys) 0 == sumAcc xs 0 + sumAcc ys 0
