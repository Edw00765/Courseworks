

smallestSquare :: Int
smallestSquare = head [x | x <- [1000..], x*x > 1000000]

divides :: Int -> Int -> Bool
divides 0 _ = False
divides a b 
    | b `mod` a == 0 = True
    | otherwise = False

prime :: Int -> Bool
prime n
    | n <= 1 = False
    | otherwise = foldr1 (&&) [not (divides x n) | x <- [2..n-1]]

foldr11 :: (a -> a -> a) -> [a] -> a
foldr11 _ [x] = x
foldr11 f (x:xs) = f x (foldr11 f xs)

allLow :: String -> Bool
allLow [] = True
allLow xs = foldr1 (&&) [elem y ['a'..'z'] | y <- xs]

merge :: [Int] -> [Int] -> [Int]
merge xs [] = xs
merge [] xs = xs
merge (x:xs) (y:ys)
    | x <= y = x : merge xs (y:ys)
    | otherwise = y : merge (x:xs) ys

mSort :: [Int] -> [Int]
mSort [] = []
mSort (x:xs) = merge [x] (mSort xs)

insert :: Ord a => a -> [a] -> [a]
insert a [] = [a]
insert a (x:xs)
    | a < x = a : x : xs
    | otherwise = x : insert a xs

sorting [] = []
sorting (x:xs) = insert x (sorting xs)

iSort :: Ord a => [a] -> [a]
iSort [] = []
iSort (x:xs) = reverse (sorting (x:xs))

zip1 :: [a] -> [b] -> [(a,b)]
zip1 [] [] = []
zip1 (x:xs) (y:ys) = (x, y) : zip1 xs ys

unzip1 :: [(a,b)] -> ([a], [b])
unzip1 [] = ([], [])
unzip1 ((a,b):xs) = (a : as, b : bs)
    where (as, bs) = unzip1 xs

inverseUnzip :: ([a], [b]) -> [(a,b)]
inverseUnzip ([], []) = []
inverseUnzip (x:xs, y:ys) = (x, y) : inverseUnzip (xs, ys)

divtail :: Int -> Int -> Int -> Int
divtail n m acc
    | n < m = acc
    | otherwise = divtail (n-m) m (acc+1)