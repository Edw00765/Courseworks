#include <stdio.h>
/*
void swap(int* array, int m, int n){
    int valueM = array[m];
    array[m] = array[n];
    array[n] = valueM;
}

void swapPairs(int* array, int length){
    for(int i = 0; i < length-1; i++){
        if(array[i] > array[i+1]){
            swap(array, i, i+1);
        }
    }
}

void bubbleSort(int* a, int length){
    for(int i = 0; i < length; i++){
        swapPairs(a, length);
    }
}

int main() {
    int arr[] = {5, 2, 7, 1, 3};
    int length = sizeof(arr) / sizeof(arr[0]);
    
    printf("Original array: ");
    for(int i = 0; i < length; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    
    bubbleSort(arr, length);
    
    printf("Sorted array: ");
    for(int i = 0; i < length; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    
    return 0;
}

char* copy(char* word){
    int length = strlen(word);
    char* newCopy = (char*)malloc((length + 1) * sizeof(char));
    char* pointer = newCopy;
    for(int i = 0; i < length + 1; i++){
        *pointer = *word;
        pointer += 1;
        word += 1;
    }
    return newCopy;
}*/

void printAsBinary(int n) {
    if (n == 0) {
        return;
    }
    int remainder = n % 2;
    printAsBinary(n / 2);
    printf("%d", remainder);
}

int main() {
    int num = 4;
    printAsBinary(num);
    printf("\n");
    return 0;
}

int compareStrings(char* str1, char* str2) {
    while (*str1 != '\0' && *str2 != '\0') {
        if (*str1 != *str2) {
            return 0;
        }
        str1++;
        str2++;
    }
    return (*str1 == '\0' && *str2 == '\0');
}