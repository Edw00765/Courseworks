sumFac :: Int -> Int
sumFac 1 = 1;
sumFac n = n*sumFac(n-1) + sumFac(n-1)

cubed :: [Int]
cubed = [x*x | x <- [1..10], x*x*x > 200, x*x*x < 1000]

negSum :: [Int] -> Int
negSum [] = 0
negSum xs = foldr (+) 0 [x*x | x <- xs, x < 0]

isPrime:: Int -> Int -> Bool
isPrime n divisor
    | n < 2 = False
    | divisor > (n-1) = True
    | divisor < 2 = True && (isPrime n (divisor + 1))
    | otherwise = n `mod` divisor /= 0 && (isPrime n (divisor + 1))

iter1 :: Int -> (a -> a) -> a -> a
iter1 0 _ x = x
iter1 n f x = iter1 (n - 1) f (f x)

square1 :: Int -> Int
square1 n = n*n

quarProd :: [Int] -> Int
quarProd [] = 1
quarProd xs = foldr1 (*) [iter1 2 (square1) x | x <- xs]

check1 :: [a] -> [a] -> Bool
check1 xs ys = length (xs ++ ys) == length xs + length ys

check2 :: [a] -> Bool
check2 xs = length xs >= 0

sumAcc :: [Int] -> Int -> Int
sumAcc [] acc = acc
sumAcc (x:xs) acc = sumAcc xs (x + acc)

prodInts :: IO ()
prodInts = do
    putStrLn "Enter Integers one per line, enter 0 when finished"
    product <- multiplyIntegers
    putStrLn $ "Product: " ++ show product

multiplyIntegers :: IO Int
multiplyIntegers = do
    line <- getLine
    let number = read line :: Int
    if number == 0
        then return 1
        else do
            restProduct <- multiplyIntegers
            return (number * restProduct)

