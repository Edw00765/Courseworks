#include <stddef.h>

/*int negSum(int* intArray, int length){
    int sum = 0;
    if (length < 1){
        return 0;
    }
    for(int i = 0; i < length; i++){
        if(intArray[i] < 0){
            sum = sum + intArray[i];
        }
    }
    return sum;
}

int negSumpointer(int* intArray, int length){
    int* pointer = intArray;
    int sum = 0;
    if (length < 1){
        return 0;
    }
    for(int i = 0; i < length; i++){
        if(*(pointer + i) < 0){
            sum = sum + *(pointer + i);
        }
    }
    return sum;
}

int** copy(int** array, int length){
    int** pointer = array;
    int** arraycopy = (int**)malloc(length * sizeof(int*));
    for (int i = 0; i < length; i++){
        arraycopy[i] = pointer[i];
    }
    return arraycopy;
}

struct node{
    int value;
    struct node* nextNode;
};

void addNode(struct node* existingNode, int value){
    struct node* newNode = (struct node*)malloc(sizeof(struct node));
    newNode -> value = value;
    newNode -> nextNode = NULL;
    while(existingNode -> nextNode != NULL){
        existingNode = existingNode -> nextNode;
    }
    existingNode -> nextNode = newNode;
}*/

int find(char* s1, char* s2){
    int starting = -1;
    int fraction = 0.1;
    int acc = 0;
    char* pointers1 = s1;
    while(*pointers1 != '\0'){
        char* pointers2 = s2;
        while(*pointers2 != '\0'){
            if(*pointers1 == *pointers2){
                starting = acc;
                pointers1 += 1;
                pointers2 += 1;
            } else {
                break;
            }
        }
        if(*pointers2 == '\0'){
            return starting;
        }
    acc++;
    pointers1++;
    }
    return -1;
}

double stringToDouble(char* str){
    double result = 0.0;
    int negative = 1;
    int fraction = 0.1;
    if(*str == '-'){
        negative = -1;
        str += 1;
    }
    while(*str >= 0 && *str <= 9){
        result = result * 10 + *str;
        str += 1;
    }
    if(*str == '.'){
        str += 1;
        while(*str >= 0 && *str <= '9'){
            result += *str * fraction;
            fraction = fraction * 0.1;
            str += 1;
        }
    }
    return result * negative;
}
//abcd
//bcdf