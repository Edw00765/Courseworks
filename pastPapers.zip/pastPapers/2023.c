#include <stddef.h>

int occurs(int array[], int n, int length){
    int counter = 0;
    for(int i = 0; i < length; i++){
        if(array[i] == n){
            counter++;
        }
    }
    return counter;
}

int occurs(int* array, int n, int length){
    int counter = 0;
    for(int i = 0; i < length; i++){
        if(*array == n){
            counter++;
        }
        array += 1;
    }
}

struct node{
    int valueInt;
    double valueDouble;
    char* pointer;
    struct node* nextNode;
};

struct node* newNode(int valueInt, double valueDouble, char* pointer){
    struct node* newNode = (struct node*)malloc(sizeof(struct node));
    newNode -> valueInt = valueInt;
    newNode -> valueDouble = valueDouble;
    newNode -> pointer = pointer;
    newNode -> nextNode = NULL;
    return newNode;
}

struct node** nodePointers(struct node* head){
    int size = 1;
    struct node* pointer = head;
    while(pointer -> nextNode != NULL){
        size++;
        pointer = pointer -> nextNode;
    }
    struct node** array = (struct node**)malloc(size * sizeof(struct node*));
    for(int i = 0; i < size; i++){
        array[i] = head;
        head = head -> nextNode;
    }
    return array;
}

