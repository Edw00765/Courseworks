take1:: Int -> [a] -> [a]
take1 n [] = []
take1 n (x:xs)
    | n < 0 = []
    | otherwise = x : take1 (n-1) xs

divisors :: Int -> [Int]
divisors 0 = []
divisors n = [x | x <- [1..n], n `mod` x == 0]

isPrime :: Int -> Bool
isPrime n
    | n < 2 = False
    | otherwise = length (divisors n) == 2

cuber :: [Int] -> Int
cuber xs = foldr (*) 1 (map (^3) (filter (> 0) xs))

mono :: (Int -> Int) -> Int -> Bool
mono f n = all (\x -> f x <= f (x+1)) [1..n-1]

snoc :: a -> [a] -> [a]
snoc a [] = [a]
snoc a xs = xs ++ [a]

rev :: [a] -> [a]
rev xs -> foldr (snoc) [] xs

iter :: Int -> (a -> a) -> a -> a
iter 0 _ x = x
iter n f x = f (iter (n-1) f x)

iter' :: Int -> (a -> a) -> a -> a
iter' 0 _ x = x
iter' n f x = foldr . id (replicate n f) x

data NTree = NilTree | Node Int (data NTree) (data NTree)

ntSum :: NTree -> Int
ntSum NilTree = 0
ntSum (Node n left right) = n + (ntSum left) + (ntSum right)

ntList :: NTree -> [Int]
ntList NilTree = []
ntList (Node n left right)  = n : ntList left ++ ntList right

fac1 :: Int -> Int
fac1 0 = 1
fac1 n = n * fac1 (n-1)

fac2 :: Int -> Int
fac2 0 = 1
fac2 n = foldr (*) 1 [1..n]

test11 :: Int -> Bool
test11 n = fac1 n == n * fac1(n-1) && fac2 n == n * fac2(n-1)

test12 :: Bool
test12 = fac1 0 == 1 && fac2 0 == 1



testInts :: IO ()
do
    input <- getLine
    let num = read input :: Int
