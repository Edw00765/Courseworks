int countChar(char* word, char character){
    int counter = 0;
    char* pointer = word;
    int inword = strlen(word);
    for (int i = 0; i < inword; i++){
        if(*pointer == character){
            counter++;
        }
        pointer++;
    }
    return counter;
}

int* vowelCount(char* word){
    int* array = (int*)malloc(5 * sizeof(int));
    array[0] = countChar(word, 'a');
    array[1] = countChar(word, 'e');
    array[2] = countChar(word, 'i');
    array[3] = countChar(word, 'o');
    array[4] = countChar(word, 'u');
}

struct node{
    char* value;
    struct node* nextNode;
};

struct node* newNode(char* word){
    struct node* node = (struct node*)malloc(sizeof(struct node));
    node -> value = (char*)malloc((strlen(word) + 1) * sizeof(char));
    node -> value = strncpy(node -> value, word, strlen(word)+1);
    return node;
}

struct node* stringArray(char** array, int size){
    if(size==1){
        struct node* currentNode = newNode(array[0]);
        return currentNode;
    }
    int i = 0;
    if(0 < size){
        struct node* currentNode = newNode(array[i]);
        currentNode -> nextNode = stringArray((array + 1), (size-1));
        return currentNode;
    }
}

void deleteLinkedList(struct node* head){
    struct node* current = head;
    struct node* next;
    while (current != NULL){
        next = current -> nextNode;
        free(current -> value);
        free(current);
        current = next;
    }
}

