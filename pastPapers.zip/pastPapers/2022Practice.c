#include <stdio.h>
#include <string.h>

int numberOfDigits(int num){
    if ((num / 10) == 0){
        return 1;
    } else {
        return 1 + numberOfDigits(num / 10);
    }
}

char* toString(int num){
    int digitCount = numberOfDigits(num);
    int isNegative = 0;
    if (num < 0){
        isNegative = 1;
        digitCount++;
        num = -num;
    }
    char* numchar = (char*)malloc((digitCount + 1) * sizeof(char));
    char* pointer = numchar;
    if (isNegative){
        *pointer = '-';
        pointer++;
        digitCount--;
    }
    pointer = pointer + digitCount + 1;
    *pointer = '\0';
    pointer--;
    while (digitCount > 0) {
        *pointer = num % 10;
        num /= 10;
        digitCount--;
        pointer--;
    }
    return numchar;
}


struct File{
    char filename[100];
    int size;
    char date[20];
};

struct File* filepointer(struct File* file, char* filename, char* date, int size){
    strncpy(file -> filename, filename, sizeof(file -> filename));
    strncpy(file -> date, date, sizeof(file -> date));
    file -> size = size;
    return file;
}


//the directory struct could be modified by adding a link to an address of another directory
struct Directory{
    char directoryName[100];
    int numberOfFiles;
    struct File** files;
    struct Directory* subDirectory;
};

struct Directory* dirPointer(char* directoryname, int numoffiles, struct File** filePointerArray){
    struct Directory* dir = (struct Directory*)malloc(sizeof(struct Directory));
    strncpy(dir -> directoryName, directoryname, sizeof(dir -> directoryName) -1);
    dir -> directoryName[sizeof(dir->directoryName) - 1] = '\0';
    dir -> numberOfFiles = numoffiles;
    dir -> files = filePointerArray;
    return dir;
}

void directoryAddFile(struct Directory* dir, struct File* file){
    dir -> files = realloc(dir->files, (dir->numberOfFiles + 1) * sizeof(struct File*));
    dir -> files[dir->numberOfFiles] = file;
    dir -> numberOfFiles++;
}

char* toString(int n){
    int size = numberOfDigits(n);
    int isNeg = 0;
    if (n < 0){
        isNeg = 1;
    }
    char* inChar = (char*)malloc((size + 1 + isNeg) * sizeof(char));
    char* head = inChar;
    if(isNeg){
        *inChar = '-';
        n = n * -1;
        inChar += 1;
    }
    *(inChar + size) = '\0';
    inChar = inChar + size - 1;
    while(n != 0){
        *inChar = '0' + n%10;
        inChar = inChar - 1;
        n = n / 10;
    }
    return head;
}