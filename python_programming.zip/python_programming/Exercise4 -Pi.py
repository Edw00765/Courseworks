from random import random

def main():
    pointsHit = 0
    for i in range(10000):
        points = [random(), random()]
        '''points[0] is x and points[1] is y'''
        if points[0]**2 + points[1]**2 <= 1:
            pointsHit = pointsHit + 1
    pi = pointsHit/10000*4
    print(pi)

main()