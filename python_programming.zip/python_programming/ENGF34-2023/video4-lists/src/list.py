days = ["mon", "tues", "weds", "thurs", "fri"]

for day_num in range(0, len(days)):
    print(day_num, days[day_num])

for day in days:
    print(day)
