# ENGF34-2023

This is the git repository for ENGF0034.  We keep assignments, course
transscripts, etc in git, so you can easily download them during term,
or update them if we release fixed versions.

If you've not used git before, please install it on your computer.  Then to clone this entire respository:

git clone https://github.com/mhandley/ENGF34-2023.git

This will make a copy of this repository in the ENGF34-2023 folder on your computer.

Later, when we add more material, go into that folder and:

git pull https://github.com/mhandley/ENGF34-2023.git

This will update your local copy from the master repository.




