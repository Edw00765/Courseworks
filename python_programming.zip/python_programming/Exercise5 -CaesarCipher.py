import enchant
dictionary = enchant.Dict("en_US")

def main():
    encrypted = input('What is the encrypted message? ')
    words = encrypted.split()
    first_word = words[0]
    alphabets = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    num = 0
    while num < len(alphabets):
        decrypted = ''
        decrypted_first = ''
        for letters in encrypted:
            if letters in alphabets:
                numInAlphabet = alphabets.find(letters)
                decrypted = decrypted + alphabets[numInAlphabet - num]
        for letters in first_word:
            if letters in alphabets:
                numInAlphabet = alphabets.find(letters)
                decrypted_first = decrypted_first + alphabets[numInAlphabet - num]
        is_english = dictionary.check(decrypted_first)
        if is_english == True:
            print(decrypted)
        num = num + 1
main()