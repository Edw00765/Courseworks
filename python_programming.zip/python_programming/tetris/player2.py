from board import Direction, Rotation, Action, Shape, Board
from random import Random
import time


class Player:
    def choose_action(self, board):
        raise NotImplementedError


class EdwardPlayer(Player):
    def __init__(self, seed=None):
        self.random = Random(seed)
        target_x = 0

    def print_board(self, board):
        print("--------")
        for y in range(24):
            s = ""
            for x in range(10):
                if (x,y) in board.cells:
                    s += "#"
                else:
                    s += "."
            print(s, y)

    def move_to_target(self, cloned_board, target_x, rotations):
        has_landed = False
        if cloned_board.falling is not None:
            if rotations == 0:
                cloned_board.rotate(Rotation.Clockwise)
            elif rotations == 1:
                cloned_board.rotate(Rotation.Clockwise)
                cloned_board.rotate(Rotation.Clockwise)
            elif rotations == 2:
                cloned_board.rotate(Rotation.Anticlockwise)
            if cloned_board.falling is not None:
                while has_landed == False and target_x < cloned_board.falling.left:
                    has_landed = cloned_board.move(Direction.Left)
                while has_landed == False and target_x > cloned_board.falling.right:
                    has_landed = cloned_board.move(Direction.Right)
            else:
                has_landed = True
        return has_landed

    def get_aggregate_height(self, cloned_board): #tested, it should be fine
        aggregate_height = 0
        for x1 in range(0, 10):
            current_greatest_y = 0
            for (x, y) in cloned_board.cells:
                if x == x1 and cloned_board.height - y > current_greatest_y:
                    current_greatest_y = cloned_board.height - y
            aggregate_height = aggregate_height + current_greatest_y
        self.print_board(cloned_board)
        print("the agg height is ", aggregate_height)
        return aggregate_height

    def get_complete_lines(self, cloned_board): #tested
        complete_lines = 0
        for y1 in range(0, 24):
            counter = 0
            for (x, y) in cloned_board.cells:
                if y == y1:
                    counter += 1
            if counter == 10:
                complete_lines += 1
        return(complete_lines)

    def get_holes(self, cloned_board): #tested, it should work
        holes = 0
        for x1 in range(0, 10):
            highest_y = 0
            counter = 1
            for (x, y) in cloned_board.cells:
                if cloned_board.height - y > 1 and x == x1:
                    if cloned_board.height - y > highest_y:
                        highest_y = cloned_board.height - y
            for(x, y) in cloned_board.cells:
                if cloned_board.height - y == highest_y and x == x1:
                    while counter < highest_y:
                        if (x, y + counter) not in cloned_board.cells:
                            holes += 1
                        counter += 1
        return holes

                    # if (x, y + 1) not in cloned_board.cells:
                    #     holes += 1
                    # if (x, y + 2) not in cloned_board.cells and cloned_board.height - y > 2:
                    #     holes += 1
                    # if (x, y + 3) not in cloned_board.cells and cloned_board.height - y > 3:
                    #     holes += 1
                    # if (x, y + 4) not in cloned_board.cells and cloned_board.height - y > 4:
                    #     holes += 1
                    # if (x, y + 5) not in cloned_board.cells and cloned_board.height - y > 5:
                    #     holes += 1
        return holes
    
    def get_bumpiness(self, cloned_board): #tested
        bumpiness = 0
        for x1 in range(0, 10):
            current_greatest_y1 = 0
            current_greatest_y2 = 0
            for (x, y) in cloned_board.cells:
                if x == x1 and cloned_board.height - y > current_greatest_y1:
                    current_greatest_y1 = cloned_board.height - y
            for (x, y) in cloned_board.cells:
                if x == x1 + 1 and cloned_board.height - y > current_greatest_y2:
                    current_greatest_y2 = cloned_board.height - y
            if current_greatest_y2 > current_greatest_y1:
                bumpiness = bumpiness + (current_greatest_y2 - current_greatest_y1) ** 1.04 #highest is ** 1.04
            else:
                bumpiness = bumpiness + (current_greatest_y1 - current_greatest_y2) ** 1.04 #highest is ** 1.04
        return bumpiness
                

    def scoring(self, cloned_board):
        a = -15.7 #16.2 was best
        b = 0.5
        c = -19.15 #15.65 was best
        d = -10.2 #10 was best

        score = 100000 + a * self.get_aggregate_height(cloned_board) + b * self.highest_y(cloned_board) * self.get_complete_lines(cloned_board) ** 1.7  + c * self.get_holes(cloned_board) + d * self.get_bumpiness(cloned_board) - self.highest_y(cloned_board) ** 1.2 #highest was 1.3
        return score

    def use_bomb(self, cloned_board):
        for x1 in range(0, 10):
            for (x, y) in cloned_board.cells:
                if cloned_board.height - y > 4:
                    if (x, y + 1) not in cloned_board.cells and (x, y + 2) not in cloned_board.cells and (x, y + 3) not in cloned_board.cells and (x, y + 4) not in cloned_board.cells:
                        return x
                    if cloned_board.height - y > 17:
                        return x
        return -1
    
    def use_discard(self, cloned_board, best_x, best_rotation):
        """
        im going to use discard if it creates a hole, not yet implemented
        """
        holes = self.get_holes(cloned_board)
        if holes > 0:
            return 1
        else:
            return 0
    
    def ready_clear_block(self, board):
        line = 0
        for y1 in range(0, 3):
            for x1 in range(0, 8):
                counter1 = 0
                counter2 = 0
                for (x, y) in board.cells:
                    if board.height - y == y1:
                        counter1 += 1
                for (x, y) in board.cells:
                    if board.height - y == y1 + 1:
                        counter2 += 1
            if counter1 == 8 and counter2 == 8:
                line += 1
        for (x, y) in board.cells:
            if 8 == x:
                line = 0
        if line >= 2:
            return 1
        return 0
    
    def highest_y(self, board):
        highest = 0
        for (x, y) in board.cells:
            if board.height - y > highest:
                highest = board.height - y
        return highest
    
    def ready_clear(self, board):
            line = 0
            for y1 in range(0, 6):
                counter = 0
                for x1 in range(0, 9):
                    for (x, y) in board.cells:
                        if board.height - y == y1 and x == x1:
                            counter += 1
                for (x, y) in board.cells:
                    if board.height - y > 1 and board.height - y == y1:
                        if (x, y + 1) not in board.cells:
                            return 2
                if counter == 9:
                    line += 1
            for (x, y) in board.cells:
                if x == 9 and board.height - y != 1:
                    if (x, y + 1) not in board.cells:
                        line = 2
            if line >= 3:
                print("tetris")
                return 1
            return 0

    # def choose_movement(self, board):
    #     best_x = 0
    #     best_rotation = 0
    #     best_score = 0
    #     rotations = 0
    #     discard = 0
    #     highest = self.highest_y(board)
    #     if self.ready_clear(board) == 1 and board.falling.shape == Shape.I and highest <= 13:
    #         best_rotation = 4
    #         best_x = 9
    #     elif self.ready_clear_block(board) == 1 and board.falling.shape == Shape.O:
    #         best_rotation = 4
    #         best_x = 9
    #     elif highest > 13 or highest > 13 and board.falling.shape == Shape.I:
    #         while rotations < 4:
    #             for target_x in range(0, 10):
    #                 cloned_board = board.clone()
    #                 rotations_2 = 0       
    #                 has_landed = self.move_to_target(cloned_board, target_x, rotations)
    #                 if has_landed == False:
    #                     cloned_board.move(Direction.Drop)
    #                 has_landed_2 = False
    #                 while rotations_2 < 4:
    #                     for target_x2 in range(0, 10):
    #                         has_landed_2 = self.move_to_target(cloned_board, target_x2, rotations_2)
    #                         if has_landed_2 == False:
    #                             cloned_board.move(Direction.Drop)
    #                     current_score = self.scoring(cloned_board)
    #                     if current_score > best_score:
    #                         best_score = current_score
    #                         best_x = target_x
    #                         best_rotation = rotations
    #                         discard = self.use_discard(cloned_board, best_x, best_rotation)
    #             rotations += 1
    #     else:
    #         while rotations < 4:
    #             for target_x in range(0, 9):
    #                 cloned_board = board.clone()
    #                 rotations_2 = 0       
    #                 has_landed = self.move_to_target(cloned_board, target_x, rotations)
    #                 if has_landed == False:
    #                     cloned_board.move(Direction.Drop)
    #                 cloned_board.place_next_block
    #                 while rotations_2 < 4:
    #                     for target_x2 in range(0, 10):
    #                         has_landed_2 = self.move_to_target(cloned_board, target_x2, rotations_2)
    #                         if has_landed_2 == False:
    #                             cloned_board.move(Direction.Drop)
    #                         current_score = self.scoring(cloned_board)
    #                 if current_score > best_score:
    #                     best_score = current_score
    #                     best_x = target_x
    #                     best_rotation = rotations
    #                     discard = self.use_discard(cloned_board, best_x, best_rotation)
    #             rotations += 1
    #     return best_x, best_rotation, discard

    def choose_movement(self, board):
        best_x = 0
        best_rotation = 0
        best_score = 0
        rotations = 0
        discard = 0
        highest = self.highest_y(board)
        if self.ready_clear(board) == 1 and board.falling.shape == Shape.I and highest <= 16:
            best_rotation = 4
            best_x = 9
        elif self.ready_clear_block(board) == 1 and board.falling.shape == Shape.O:
            best_rotation = 4
            best_x = 9
        elif self.ready_clear(board) == 2:
            while rotations < 4:
                for target_x in range(0, 10):
                    cloned_board = board.clone()          
                    has_landed = self.move_to_target(cloned_board, target_x, rotations)
                    if has_landed == False:
                        cloned_board.move(Direction.Drop)
                    current_score = self.scoring(cloned_board)
                    if current_score > best_score:
                        best_score = current_score
                        best_x = target_x
                        best_rotation = rotations
                        discard = self.use_discard(cloned_board, best_x, best_rotation)
                rotations += 1
            print("there is a hole")
        elif highest > 16 or highest > 15 and board.falling.shape == Shape.I:
            while rotations < 4:
                for target_x in range(0, 10):
                    cloned_board = board.clone()          
                    has_landed = self.move_to_target(cloned_board, target_x, rotations)
                    if has_landed == False:
                        cloned_board.move(Direction.Drop)
                    current_score = self.scoring(cloned_board)
                    if current_score > best_score:
                        best_score = current_score
                        best_x = target_x
                        best_rotation = rotations
                        discard = self.use_discard(cloned_board, best_x, best_rotation)
                rotations += 1
        else:
            while rotations < 4:
                for target_x in range(0, 9):
                    cloned_board = board.clone()              
                    has_landed = self.move_to_target(cloned_board, target_x, rotations)
                    if has_landed == False:
                        cloned_board.move(Direction.Drop)
                    current_score = self.scoring(cloned_board)
                    if current_score > best_score:
                        best_score = current_score
                        best_x = target_x
                        best_rotation = rotations
                        discard = self.use_discard(cloned_board, best_x, best_rotation)
                rotations += 1
        return best_x, best_rotation, discard

    def choose_action(self, board):
        best_x, best_rotation, use_discard = self.choose_movement(board)
        moves = []
        landed = False
        x_of_bomb = self.use_bomb(board)
        if x_of_bomb != -1 and board.bombs_remaining > 0: #and board.falling.shape != Shape.I
            moves.append(Action.Discard)
            moves.append(Action.Bomb)
            while landed == False and x_of_bomb < board.falling.left:
                landed = board.move(Direction.Left)
                moves.append(Direction.Left)
            while landed == False and x_of_bomb > board.falling.right:
                landed = board.move(Direction.Right)
                moves.append(Direction.Right)
        elif use_discard != 0 and board.discards_remaining > 0: #and board.falling.shape != Shape.I
            moves.append(Action.Discard)
        else:
            if best_rotation == 0:
                board.rotate(Rotation.Clockwise)
                moves.append(Rotation.Clockwise)
            elif best_rotation == 1:
                board.rotate(Rotation.Clockwise)
                board.rotate(Rotation.Clockwise)
                moves.append(Rotation.Clockwise)
                moves.append(Rotation.Clockwise)
            elif best_rotation == 2:
                board.rotate(Rotation.Anticlockwise)
                moves.append(Rotation.Anticlockwise)
            while landed == False and best_x < board.falling.left:
                landed = board.move(Direction.Left)
                moves.append(Direction.Left)
            while landed == False and best_x > board.falling.right:
                landed = board.move(Direction.Right)
                moves.append(Direction.Right)
            if landed == False:
                board.move(Direction.Drop)
                moves.append(Direction.Drop)
        #time.sleep(10)
        return moves


            
SelectedPlayer = EdwardPlayer



#see current block and next block
#copy current board
#move the block to every single possible most bottom row and determine score
#rotate the block and try every single possible bottom row, repeat until all possible locations are covered.
#check the next block and also try to put every single possible location and orientation on top of the first block.
#return the highest scoring location of both combined block and return the path of the first block to that location
#if highest height is 21 or higher, use the bomb to lower it down
#rotate then move it down

#I can try to make it so that the blocks only go from 0 to 8, the 9th block is only reserved for the I block or
#J block, so it only clears three or four rows in a row