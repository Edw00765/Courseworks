def main():
    number = int(input("What is your number? "))
    if abs(number) % 2 == 1:
        print("The number is odd.")
    else:
        print("The number is even.")

main()