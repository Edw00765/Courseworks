Pacman Protocol Specification


Edward Tandanu, SN: 23089541


Terminology
===========
This specification uses the terms MUST, SHOULD, and MAY as defined in
RFC 2119 [rfc2119]


The pacman protocol runs over UDP, using a port of 1234.
There are 9 message types: MAZE_UPDATE, MAZE_STATUS_UPDATE, SCORE_UPDATE, INIT, PACMAN_STATUS_UPDATE, GHOST_STATUS_UPDATE, VERIFY, PACMAN_UPDATE, and GHOST_STATUS_UPDATE.


When running pacman, it will be using the Client-Server Mode, which means that one of the players will act as a “server” while the other acts as a “client”. The server must run first, then the client connects to the server.


In the message SCORE_UPDATE, the local and remote identifier is for the local computer, which means that the remote computer will have to read it the other way around.
EX:
If the local computer is sending the REMOTE score value, then the remote computer will read it as local value.


Game Overview
=============
After the connection between the two computers has been made, they will then send their maze to the other computer. They will achieve this by sending an INIT message to each other, and they will keep sending the message until they receive a VERIFY message from the other computer. While the game is on startup, the computers will send a MAZE_STATUS_UPDATE where they will inform each other that the maze status is on STARTUP.


When the game starts, the local ghost and the local pacman will be modelled on the local computer, while the remote ghost and remote pacman will be modelled on the remote computer. They will then send a MAZE_STATUS_UPDATE to the other computer, informing each other that the maze status has been set to CHASE. In every frame, the message PACMAN_UPDATE and GHOST_UPDATE is sent, while the MAZE_UPDATE is sent every time something on the local map is eaten. The remote computer receives this data and uses it to display the maze, pacman, and ghost of the local computer on their minimap. The local computer will also receive data from their computer, which allows the local computer to load their map, ghost, and pacman in the local minimap. The SCORE_UPDATE is sent along when our pacman eats a food or when it eats a ghost.


During the event that the local pacman visits the remote screen, the local computer will send a PACMAN_STATUS_UPDATE to the remote computer with the message that the status of the pacman is now AWAY. During the event that the AWAY pacman is coming back home, the local computer will send a PACMAN_STATUS_UPDATE to the remote computer, with the message that the status of the pacman is now LOCAL. This means that the remote computer will no longer have to show it on the screen as the pacman is now REMOTE and not FOREIGN.


During the event that our pacman dies whether it is LOCAL or AWAY, it will send a PACMAN_STATUS_UPDATE, where it informs the other computer that our pacman has died, and that the remaining lives left is reduced by one. After it revives, there will be another PACMAN_STATUS_UPDATE sent, where the message says that the pacman is now alive and is LOCAL. When our pacman eats a local powerpill, the local computer will send a MAZE_STATUS_UPDATE where the status of the maze is now set to FRIGHTEN. It will also send a GHOST_STATUS_UPDATE where the status of all the ghosts are FRIGHTEN. During the event that our pacman eats a remote powerpill, the remote computer will recognize that our pacman has eaten the powerpill as it receives the x and y position of our AWAY pacman constantly. When the x and y position of our AWAY pacman is the same as the x and y position of a powerpill, it will recognize that our pacman ate a powerpill. The remote computer will then send a MAZE_STATUS_UPDATE with the message that the maze status is now FRIGHTEN. It will then also send a GHOST_STATUS_UPDATE where the status of the ghost is now FRIGHTEN.


During the event that our pacman eats a LOCAL ghost, a GHOST_STATUS_UPDATE is sent, with the message that that ghost's status has changed to EYES, along with a SCORE_UPDATE message. During the event that our pacman eats a REMOTE ghost, the remote computer recognizes that the foreign pacman has eaten one of the ghosts through the x and y position of the foreign pacman. The remote computer will then send a GHOST_STATUS_UPDATE with the message that that ghost's status has been changed to EYES, along with a SCORE_UPDATE message, but it will send our updated score.


During the event that one of the players loses their last life, the game will end. The losing player's computer will send a MAZE_STATUS_UPDATE, with the message that the game status is now GAME_OVER. It will wait until the remote computer receives this message and also sends a MAZE_STATUS_UPDATE with the status of the game being GAME_OVER. From the game over state, if a player presses "r", the maze will go to a READY_TO_RESTART state and send a MAZE_STATUS_UPDATE, telling the other computer that it's status is READY_TO_RESTART. It will wait for the other player to press "r", and when it is pressed, both maze statuses will be in READY_TO_RESTART, where it will then start the game. Both of the computers will send a MAZE_STATUS_UPDATE where the status of the maze is now CHASE.


During the event that the level is cleared, that maze's state changes to NEXT_LEVEL_WAIT and it sends a MAZE_STATUS_UPDATE while it waits for the player to get ready and plays the jingle. Completing the level doesn’t affect the level being played on the other screen, except that the pacman position is reset.


When all of these messages are being sent from the local computer to the remote computer, all of the messages except for PACMAN_UPDATE and GHOST_UPDATE require a verification from the remote computer as these data packets MUST arrive. The VERIFY packet is sent by the remote computer to the local computer whenever it receives a message that is not PACMAN_UPDATE or GHOST_UPDATE. The local computer will keep sending the event messages until it receives a VERIFY message from the remote computer.


Message Contents
================


The contents of a MAZE_UPDATE message are:


    Type: MAZE_UPDATE


    VALUE: X, Y position of the food or powerpill that was eaten. 0 on the x position means that it is at the most left of the canvas, while 650 is the most right of the canvas. 0 on the y position is at the top while 800 is the lowest part of the canvas.


The contents of a MAZE_STATUS_UPDATE message are:


    Type: MAZE_STATUS_UPDATE


    VALUE: It contains the status of the maze, whether it is on STARTUP, CHASE, FRIGHTEN, GAME_OVER, NEXT_lEVEL_WAIT, or READY_TO_RESTART.


The contents of a SCORE_UPDATE message are:


    Type: SCORE_UPDATE


    VALUE: It contains the new score of the player in decimal form.


The contents of a INIT message are:


    Type: INIT


    VALUE: It contains the file for the maze of the player, so that the remote computer will be able to access and see our map.


The contents of a PACMAN_STATUS_UPDATE message are:


    Type: PACMAN_STATUS_UPDATE


    VALUE: It contains the status of the pacman. It contains if the pacman is dead or alive, it also contains if the pacman is currently AWAY or LOCAL.


The contents of a GHOST_STATUS_UPDATE message are:


    Type: GHOST_STATUS_UPDATE


    VALUE: It contains the status of all the ghosts, whether their status is CHASE, FRIGHTEN, or EYES.


The contents of a VERIFY message are:


    Type: VERIFY


    VALUE: It contains the sequence number and type of message that it is verifying. This will inform the remote computer that it has received the event that was sent from the remote computer, making a "handshake" where the event has been acknowledged.


The contents of a PACMAN_UPDATE message are:


    Type: PACMAN_UPDATE


    VALUE: It contains the X, Y position of the pacman. 0 on the x position means that it is at the most left of the canvas, while 650 is the most right of the canvas. 0 on the y position is at the top while 800 is the lowest part of the canvas. It also contains the direction which it is facing, which is UP, DOWN, LEFT, or RIGHT. It also contains a boolean wether the pacman is moving or not.


The contents of a GHOST_UPDATE message are:


    Type: GHOST_UPDATE


    VALUE: It contains the X and Y position of all the ghosts, as well as their speed. 0 on the x position means that it is at the most left of the canvas, while 650 is the most right of the canvas. 0 on the y position is at the top while 800 is the lowest part of the canvas. It also contains the direction which it is facing, which is UP, DOWN, LEFT, or RIGHT. It also contains a boolean whether the pacman is moving or not.




Message Timing
==============


While the game is running, the message PACMAN_UPDATE and GHOST_UPDATE
should be sent once every frame, following the frames of the slower
computer as this will create a fair gameplay between the two computers as there will be no computer with an advantage.


Other messages will be sent during key events. INIT message is sent in the beginning before the game starts as the two computers will need each other's maze to start. MAZE_UPATE is sent every time food or a powerpill on the map is eaten. MAZE_STATUS_UPDATE message is sent when the game is on startup, when the game starts, when a powerpill is eaten, when one of the players lose all of their life, when they press "r" after dying, and when one of the pacman's go to the next level. SCORE_UPDATE is sent every time food is eaten or when the pacman eats a frightened ghost.


PACMAN_STATUS_UPDATE is sent every time the status of the pacman changes. This means it is sent when the pacman moves from our local computer to the remote computer, when it moves from the remote computer to the local computer, or when the pacman dies. GHOST_STATUS_UPDATE is sent whenever there is a change in status on any of the ghosts. This means that the message is sent when a pacman eats a powerpill, when the effect of the powerpill is finished, or when the frightened ghost is eaten by the pacman. VERIFY is sent whenever key events happen. If the local computer sends a message that isn't PACMAN_UPDATE or GHOST_UPDATE, the remote computer will send a verify message back to the local computer to inform it that it has received the message, and it can stop sending the message of the event.




Message Encoding
================


Messages are fixed format, binary encoded, with all integer fields
send in network byte order (i.e, big endian order).  As as message
type is fixed forward, no explicit length field is required.  More
than one message MAY be send consecutively in a single packet - this
may be useful to reduce overhead when sending multiple message at the same time.




INIT message format
-------------------------


 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   T   |      sequence number          |          U          |P|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                       Board (2635 bytes)                      |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                    Continuation of Board                      |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                           Board ...                           |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


T: Type of message, the INIT message format has the decimal value of 0


Sequence number: a 16 bit unsigned integer, initialized to zero and
incremented by one for every new message sent.  If it reaches (2^16)-1,
it wraps back round to zero.


Board: Contains the file of the board that will be used in the game.




VERIFY message format
---------------------


 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   T   |      sequence number          |  M  |      U        |P|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


T: Type of message, the verification message format has the decimal value of 1


Sequence number: It copies the sequence number of the message that I am verifying.


M: It copies the type of message of the message that it is verifying.
U: Unused bits
P: Parity bit, used for error checking.




SCORE_UPDATE message format
---------------------------


 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   T   |      sequence number          |K|         U         |P|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                       Score                 |U|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


T: Type of message, the SCORE_UPDATE message format has the decimal value of 2


Sequence number: a 16 bit unsigned integer, initialized to zero and
incremented by one for every new message sent.  If it reaches (2^16)-1,
it wraps back round to zero.


U: Unused bits.


K: a bit which represents which player's score is being sent:
    1 is when the score being sent is the LOCAL score
    0 is when the score being sent is the REMOTE score


P: Parity bit, used for error checking.


Score: Contains the decimal values of the player's score.




MAZE_STATUS_UPDATE message format
---------------------------------


 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   T   |      sequence number          |  S  |       U       |P|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


T: Type of message, the MAZE_STATUS_UPDATE message format has the decimal value of 3


Sequence number: a 16 bit unsigned integer, initialized to zero and
incremented by one for every new message sent.  If it reaches (2^16)-1,
it wraps back round to zero.


S: Status of the maze:
    STARTUP is when the decimal value of S = 0
    CHASE is when the decimal value of S = 1
    FRIGHTEN is when the decimal value of S = 2
    GAME_OVER is when the decimal value of S = 3
    NEXT_LEVEL_WAIT is when the decimal value of S = 4
    READY_TO_RESTART is when the decimal value of S = 5


U: Unused bits.


P: Parity bit, used for error checking.


MAZE_UPDATE message format
--------------------------


 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   T   |      sequence number          |     x value      |U |P|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|       y value     |     U     |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


T: Type of message, the MAZE_UPDATE message format has the decimal value of 4


Sequence number: a 16 bit unsigned integer, initialized to zero and
incremented by one for every new message sent.  If it reaches (2^16)-1,
it wraps back round to zero.


U: Unused bits.


P: Parity bit, used for error checking.


x value: A 10 bit integer which contains the decimal values of the value of
the food or powerpill's x coordinate, AWAY or LOCAL.


y value: A 10 bit integer which contains the decimal values of the value of
the food or powerpill's y coordinate, AWAY or LOCAL.




PACMAN_STATUS_UPDATE message format
-----------------------------------


 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   T   |      sequence number          |D|L|  H  |     U     |P|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


T: Type of message, the PACMAN_STATUS_UPDATE message format has the decimal value of 5


Sequence number: a 16 bit unsigned integer, initialized to zero and
incremented by one for every new message sent.  If it reaches (2^16)-1,
it wraps back round to zero.


U: Unused bits.


P: Parity bit, used for error checking.


D: It is a bit which shows if the pacman is DEAD or ALIVE:
    DEAD is when the bit's decimal value = 0
    ALIVE is when the bit's decimal value = 1


L: It tells the status of the pacman if it is LOCAL or AWAY:
    LOCAL is when the bit's decimal value = 0
    ALIVE is when the bit's decimal value = 1


H: It is a three bit integer which decimal values give the remaining life of the pacman




GHOST_STATUS_UPDATE message format
----------------------------------


 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   T   |      sequence number          | N | S |      U      |P|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+
 N | S |    U   |
+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+
 N | S |    U   |
+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+
 N | S |    U   |
+-+-+-+-+-+-+-+-+


T: Type of message, the GHOST_STATUS_UPDATE message format has the decimal value of 6


Sequence number: a 16 bit unsigned integer, initialized to zero and
incremented by one for every new message sent.  If it reaches (2^16)-1,
it wraps back round to zero.


U: Unused bits.


P: Parity bit, used for error checking.


N: It is a two bit integer which identifies the ghost.


S: it is a two bit integer which gives the status of the ghosts:
    CHASE is when the bit's decimal value = 0
    FRIGHTENED is when the bit's decimal value = 1
    EYES is when the bit's decimal value = 2




PACMAN_UPDATE message format
----------------------------


 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   T   |     x value       |       y value     | D |M|    U    |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


T: Type of message, the PACMAN_UPDATE message format has the decimal value of 7


U: Unused bits.


x value: A 10 bit integer which contains the decimal values of the value of
our pacman's x coordinate, AWAY or LOCAL.


y value: A 10 bit integer which contains the decimal values of the value of
our pacman's y coordinate, AWAY or LOCAL.


D: A 2 bit integer which gives the direction of our pacman:
    UP is when the decimal value = 0
    DOWN is when the decimal value = 1
    LEFT is when the decimal value = 2
    RIGHT is when the decimal value = 3


M: A 1 bit boolean which gives tells us if our pacman is moving or not:
    MOVING is when the decimal value = 1
    STOPPED is when the decimal value = 0




GHOST_UPDATE message format
---------------------------


 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   T   |     x value       |       y value     | D | N |   U   |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                            Speed                              |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|     x value       |       y value     | D | N |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                            Speed                              |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|     x value       |       y value     | D | N |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                            Speed                              |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|     x value       |       y value     | D | N |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                            Speed                              |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


T: Type of message, the GHOST_UPDATE message format has the decimal value of 8


U: Unused bits.
