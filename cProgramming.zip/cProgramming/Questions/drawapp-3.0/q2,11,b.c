#include <stdio.h>
#include <math.h>

int main(void)
{
    for(int number = 1; number <= 101; number++)
    {
        if (number % 2 == 0)
        {
            int squared = number * number;
            printf("%d, %d", number, squared);
            printf("\n");
        }
    }
    return 0;
}