#include <stdio.h>

int main(void)
{
    for(int i = 0; i<6; i++){
        for(int c = 0; c<i; c++){
            printf(" ");
        }
        int j = 6-i;
        while(j>0){
            printf("*");
            j--;
        }
        
        printf("\n");
    }
}
//in every row, print ' ' for each column and otherwise print *