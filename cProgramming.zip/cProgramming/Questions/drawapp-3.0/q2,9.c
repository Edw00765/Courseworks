#include <stdio.h>

int main(void)
{
    for(int row = 0; row < 5; row++)
    {
    printf("*");
        int space = row - 1;
        if(space > 0)
        {
            for(int spaces = 0; spaces < space; space--)
            {
                if (spaces < space)
                {
                    printf(" ");
                } 
            }
        }
        if (space == 0)
        {
            printf("*");
        }
        printf("\n");
    }
//THIS IS FOR THE OPPOSITE DIRECTION
    for(int row = 3; row >= 0; row--)
    {
    printf("*");
        int space = row - 1;
        if(space > 0)
        {
            for(int spaces = 0; spaces < space; space--)
            {
                if (spaces < space)
                {
                    printf(" ");
                } 
            }
        }
        if (space == 0)
        {
            printf("*");
        }
    printf("\n");
    }
}