#include <stdio.h>

int main(void)
{
    for(int i = 0; i<5; i++){
        for(int c = 0; c<i; c++){
            printf(" ");
        }
        int j = 6;
        while(j>0){
            printf("*");
            j--;
        }
        printf("\n");
    }
     for(int m = 0; m<4; m++){
        for(int n = 3; n>m; n--){
            printf(" ");
        }
        int t = 6;
        while(t>0){
            printf("*");
            t--;
        }
        printf("\n");
    }
}