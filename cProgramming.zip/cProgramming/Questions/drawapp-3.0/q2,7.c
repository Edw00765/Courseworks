#include <stdio.h>

int main(void)
{
    for(int row = 0; row<7; row++){
        for(int col =0; col<8; col++){
            if(col>2&&col<5&&row==3){
                        printf(" ");
            }
            if(col>1&&col<6 && row>1&& row<5 && !(col>2&&col<5&&row==3)){
                    printf("#");
            }
            if((col>0 && col<7 && row>0 && row<6) && !(col>1&&col<6 && row>1&& row<5)){
                printf(" ");
            }
            if(!(col>0 && col<7 && row>0 && row<6)){
                printf("*");
            }
        }
        printf("\n");
    }
}