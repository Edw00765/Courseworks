#include <stdio.h>

int main(void)
{
   int n = 0;
   for (n = 1; n < 11; n = n+1)
   {
      int multiple = n * 13;
      printf("%d\n", multiple);
   }
   return 0;
}
