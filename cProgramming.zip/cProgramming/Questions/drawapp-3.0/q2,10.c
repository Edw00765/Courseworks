#include <stdio.h>

int main(void)
{
    for (int row = 1; row < 9; row ++)
    {
        for (int column = 0; column < 7; column ++)
        {
            if (row == 1)
            {
                printf("*");
            }
            if (column == 0 && row > 1 && !(row == 8) || column == row - 2 && !(row == 8))
            {
                printf("#");
            }
            if (!((column == 0 && row > 1)) && !(column == row - 2) && !(column == row - 1) && !(row == 1) && !(row == 8) && !(column == 6))
            {
                printf(" ");
            }
            if (column == 6 && row > 1 && !(row == 1) && !(row == 8) || column == row - 1 && !(row == 1) && !(row == 8))
            {
                printf("*");
            }
            if (row == 8)
            {
                printf("#");
            }
        }
        printf("\n");
    }
}

