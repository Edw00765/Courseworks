#include <stdio.h>
#include "graphics.h"
int main(void)
{
 drawLine(100, 200, 150, 200);
 drawLine(150, 200, 185, 165);
 drawLine(185, 165, 185, 115);
 drawLine(185, 115, 150, 79);
 drawLine(150, 79, 100, 79);
 drawLine(100, 79, 65, 115);
 drawLine(65, 115, 65, 165);
 drawLine(65, 165, 100, 200);
 return 0;
}

//why cant i compile it using gcc -o octagon octagon.c graphics.h
//I had to put include stdio.h and use gcc -o octagon octagon.c graphics.c