#include <stdio.h>
#include <math.h>

int main(void)
{
    for(int number = 1; number < 101; number++)
    {
        int squared = pow(number, 2);
        printf("%d", squared);
        printf("\n");
    }
    return 0;
}