#include <stdio.h>
int main(void)
{
    for (int number = 1; number <= 100; number++)
    {
        int divisible = 0;
        for (int i = 2; i <= number / 2; i++)
        {
            if(number % i == 0)
            {
                divisible++;
            }
        }
        if (divisible == 0)
        {
            printf("%d", number);
            printf("\n");
        }
    }
}