#include <stdio.h>

int main(void)
{
   int n = 1;
   while (n < 11)
   {
      int multiple = n * 13;
      printf("%d\n", multiple);
      n = n + 1;
   }
   return 0;
}
