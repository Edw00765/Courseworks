#include <stdio.h>
#include <stdlib.h>

struct robot{
    int xCoord;
    int yCoord;
    char direction;
    int hasMarker;
};

struct home{
    int xOfHome;
    int yOfHome;
};

struct obstacle{
    int xOfObstacle;
    int yOfObstacle;
};

struct marker{
    int xOfMarker;
    int yOfMarker;
    int markerCollected;
};

void initRobot(struct robot *myRobot, struct home myHome)
{
    myRobot->xCoord = myHome.xOfHome;
    myRobot->yCoord = myHome.yOfHome;
    myRobot->direction = 'e';
    myRobot->hasMarker = 0;
    foreground();
    setColour(green);
    fillRect(20 + 20 * myRobot->xCoord, 20 + 20 * myRobot->yCoord, 20, 20);
}

void forward(struct robot *myRobot)
{
    if (myRobot->direction == 'n')
    {
        myRobot->yCoord = myRobot->yCoord - 1;
        foreground();
        clear();
        foreground();
        setColour(green);
        fillRect(20 + 20 * myRobot->xCoord, 20 + 20 * myRobot->yCoord, 20, 20);
    }
    if (myRobot->direction == 's')
    {
        myRobot->yCoord = myRobot->yCoord + 1;
        foreground();
        clear();
        foreground();
        setColour(green);
        fillRect(20 + 20 * myRobot->xCoord, 20 + 20 * myRobot->yCoord, 20, 20);
    }
    if (myRobot->direction == 'w')
    {
        myRobot->xCoord = myRobot->xCoord - 1;
        foreground();
        clear();
        foreground();
        setColour(green);
        fillRect(20 + 20 * myRobot->xCoord, 20 + 20 * myRobot->yCoord, 20, 20);
    }
    if (myRobot->direction == 'e')
    {
        myRobot->xCoord = myRobot->xCoord + 1;
        foreground();
        clear();
        foreground();
        setColour(green);
        fillRect(20 + 20 * myRobot->xCoord, 20 + 20 * myRobot->yCoord, 20, 20);
    }
}

void left(struct robot *myRobot)
{
    if (myRobot->direction == 'n')
    {
        myRobot->direction = 'w';
    } else if (myRobot->direction == 'w')
    {
        myRobot->direction = 's';
    } else if (myRobot->direction == 's')
    {
        myRobot->direction = 'e';
    } else if (myRobot->direction == 'e')
    {
        myRobot->direction = 'n';
    }
}

void right(struct robot *myRobot)
{
    if (myRobot->direction == 'n')
    {
        myRobot->direction = 'e';
    } else if (myRobot->direction == 'w')
    {
        myRobot->direction = 'n';
    } else if (myRobot->direction == 's')
    {
        myRobot->direction = 'w';
    } else if (myRobot->direction == 'e')
    {
        myRobot->direction = 's';
    }
}

int canMoveForward(struct robot *myRobot, struct obstacle *myObstacle1, struct obstacle *myObstacle2, struct obstacle *myObstacle3)
{
    if (myRobot->direction == 'n')
    {
        if (myRobot->yCoord <= 0 || myObstacle1 -> xOfObstacle == myRobot->xCoord && myObstacle1 -> yOfObstacle == myRobot->yCoord - 1 || myObstacle2 -> xOfObstacle == myRobot->xCoord && myObstacle2 -> yOfObstacle == myRobot->yCoord - 1 || myObstacle3 -> xOfObstacle == myRobot->xCoord && myObstacle3 -> yOfObstacle == myRobot->yCoord - 1)
        {
            return 0;
        }
        return 1;
    } 
    if (myRobot->direction == 'w')
    {
        if (myRobot->xCoord <= 0 || myObstacle1 -> xOfObstacle == myRobot->xCoord - 1 && myObstacle1 -> yOfObstacle == myRobot->yCoord || myObstacle2 -> xOfObstacle == myRobot->xCoord - 1 && myObstacle2 -> yOfObstacle == myRobot->yCoord || myObstacle3 -> xOfObstacle == myRobot->xCoord - 1 && myObstacle3 -> yOfObstacle == myRobot->yCoord)
        {
            return 0;
        }
        return 1;
    } 
    if (myRobot->direction == 's')
    {
        if (myRobot->yCoord >= 9 || myObstacle1 -> xOfObstacle == myRobot->xCoord && myObstacle1 -> yOfObstacle == myRobot->yCoord + 1 || myObstacle2 -> xOfObstacle == myRobot->xCoord && myObstacle2 -> yOfObstacle == myRobot->yCoord + 1 || myObstacle3 -> xOfObstacle == myRobot->xCoord && myObstacle3 -> yOfObstacle == myRobot->yCoord + 1)
        {
            return 0;
        }
        return 1;
    }
    if (myRobot->direction == 'e')
    {
        if (myRobot->xCoord >= 9 || myObstacle1 -> xOfObstacle == myRobot->xCoord + 1 && myObstacle1 -> yOfObstacle == myRobot->yCoord || myObstacle2 -> xOfObstacle == myRobot->xCoord + 1 && myObstacle2 -> yOfObstacle == myRobot->yCoord || myObstacle3 -> xOfObstacle == myRobot->xCoord + 1 && myObstacle3 -> yOfObstacle == myRobot->yCoord)
        {
            return 0;
        }
        return 1;
    }
}

int canMoveLeft(struct robot *myRobot, struct obstacle *myObstacle1, struct obstacle *myObstacle2, struct obstacle *myObstacle3)
{
    if (myRobot->direction == 'n')
    {
        if (myRobot->xCoord <= 0 || myObstacle1 -> xOfObstacle == myRobot->xCoord - 1 && myObstacle1 -> yOfObstacle == myRobot->yCoord || myObstacle2 -> xOfObstacle == myRobot->xCoord - 1 && myObstacle2 -> yOfObstacle == myRobot->yCoord || myObstacle3 -> xOfObstacle == myRobot->xCoord - 1 && myObstacle3 -> yOfObstacle == myRobot->yCoord)
        {
            return 0;
        }
        return 1;
    } 
    if (myRobot->direction == 'w')
    {
        if (myRobot->yCoord >= 9 || myObstacle1 -> xOfObstacle == myRobot->xCoord && myObstacle1 -> yOfObstacle == myRobot->yCoord + 1 || myObstacle2 -> xOfObstacle == myRobot->xCoord && myObstacle2 -> yOfObstacle == myRobot->yCoord + 1 || myObstacle3 -> xOfObstacle == myRobot->xCoord && myObstacle3 -> yOfObstacle == myRobot->yCoord + 1)
        {
            return 0;
        }
        return 1;
    } 
    if (myRobot->direction == 's')
    {
        if (myRobot->xCoord >= 9 || myObstacle1 -> xOfObstacle == myRobot->xCoord + 1 && myObstacle1 -> yOfObstacle == myRobot->yCoord || myObstacle2 -> xOfObstacle == myRobot->xCoord + 1 && myObstacle2 -> yOfObstacle == myRobot->yCoord || myObstacle3 -> xOfObstacle == myRobot->xCoord + 1 && myObstacle3 -> yOfObstacle == myRobot->yCoord)
        {
            return 0;
        }
        return 1;
    } 
    if (myRobot->direction == 'e')
    {
        if (myRobot->yCoord <= 0 || myObstacle1 -> xOfObstacle == myRobot->xCoord && myObstacle1 -> yOfObstacle == myRobot->yCoord - 1 || myObstacle2 -> xOfObstacle == myRobot->xCoord && myObstacle2 -> yOfObstacle == myRobot->yCoord - 1 || myObstacle3 -> xOfObstacle == myRobot->xCoord && myObstacle3 -> yOfObstacle == myRobot->yCoord - 1)
        {
            return 0;
        }
        return 1;
    }
}

int canMoveRight(struct robot *myRobot, struct obstacle *myObstacle1, struct obstacle *myObstacle2, struct obstacle *myObstacle3)
{
    if (myRobot->direction == 'n')
    {
        if (myRobot->xCoord >= 9 || myObstacle1 -> xOfObstacle == myRobot->xCoord + 1 && myObstacle1 -> yOfObstacle == myRobot->yCoord || myObstacle2 -> xOfObstacle == myRobot->xCoord + 1 && myObstacle2 -> yOfObstacle == myRobot->yCoord || myObstacle3 -> xOfObstacle == myRobot->xCoord + 1 && myObstacle3 -> yOfObstacle == myRobot->yCoord)
        {
            return 0;
        } else {
            return 1;
        }
    }
    if (myRobot->direction == 'w')
    {
        if (myRobot->yCoord <= 0 || myObstacle1 -> xOfObstacle == myRobot->xCoord && myObstacle1 -> yOfObstacle == myRobot->yCoord - 1 || myObstacle2 -> xOfObstacle == myRobot->xCoord && myObstacle2 -> yOfObstacle == myRobot->yCoord - 1 || myObstacle3 -> xOfObstacle == myRobot->xCoord && myObstacle3 -> yOfObstacle == myRobot->yCoord - 1)
        {
            return 0;
        } else {
            return 1;
        }
    }
    if (myRobot->direction == 's')
    {
        if (myRobot->xCoord <= 0 || myObstacle1 -> xOfObstacle == myRobot->xCoord - 1 && myObstacle1 -> yOfObstacle == myRobot->yCoord || myObstacle2 -> xOfObstacle == myRobot->xCoord - 1 && myObstacle2 -> yOfObstacle == myRobot->yCoord || myObstacle3 -> xOfObstacle == myRobot->xCoord - 1 && myObstacle3 -> yOfObstacle == myRobot->yCoord)
        {
            return 0;
        } else {
            return 1;
        }
    }
    if (myRobot->direction == 'e')
    {
        if (myRobot->yCoord >= 9 || myObstacle1 -> xOfObstacle == myRobot->xCoord && myObstacle1 -> yOfObstacle == myRobot->yCoord + 1 || myObstacle2 -> xOfObstacle == myRobot->xCoord && myObstacle2 -> yOfObstacle == myRobot->yCoord + 1 || myObstacle3 -> xOfObstacle == myRobot->xCoord && myObstacle3 -> yOfObstacle == myRobot->yCoord + 1)
        {
            return 0;
        } else {
            return 1;
        }
    }
}

int atHome(struct robot *myRobot, struct home *myHome)
{
    if (myRobot->xCoord == myHome->xOfHome && myRobot->yCoord == myHome->yOfHome)
    {
        return 1;
    } else {
        return 0;
    }
}

void dropMarker(struct robot *myRobot)
{
    myRobot->hasMarker = 0;
}

int isCarryingAMarker(struct robot *myRobot)
{
    if (myRobot->hasMarker == 1)
    {
        return 1;
    } else {
        return 0;
    }
}

void pickUpMarker(struct robot *myRobot)
{
    myRobot->hasMarker = 1;
}


void atMarker(struct robot *myRobot, struct marker *myMarker)
{
    if (myRobot->xCoord == myMarker->xOfMarker && myRobot->yCoord == myMarker->yOfMarker)
    {
        myRobot->hasMarker = 1;
        myMarker->markerCollected = 1;
        background();
        setColour(white);
        fillRect(20 + 20 * myMarker->xOfMarker, 20 + 20 * myMarker->yOfMarker, 20, 20);
        myMarker->xOfMarker = 11;
        myMarker->yOfMarker = 11;
    }
}