#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graphics.h"
#include "robot.c"

//length of the line is 200, so each block is 20 pixels

struct Movement {
    int xCoord;
    int yCoord;
    char direction;
};

//Stack which stores the movement of the bot
struct Movement movementStack[1000];
int stackSize = 0;
// Function to push the current movement to the stack, this is used from chatgpt and edited by me
void pushMovement(struct robot *myRobot) {
    if (stackSize < 1000) { // Check if the stack is not full
        movementStack[stackSize].xCoord = myRobot->xCoord;
        movementStack[stackSize].yCoord = myRobot->yCoord;
        movementStack[stackSize].direction = myRobot->direction;
        stackSize++;
    }
}

//Makes the robot move to the previous location by updating its location to the previous coordinate. This is used from chatgpt and updated by me.
void popMovement(struct robot *myRobot) {
    if (stackSize > 0) { // Check if the stack is not empty
        stackSize--;
        myRobot->xCoord = movementStack[stackSize].xCoord;
        myRobot->yCoord = movementStack[stackSize].yCoord;
        myRobot->direction = movementStack[stackSize].direction;
        foreground();
        clear();
        foreground();
        setColour(green);
        fillRect(20 + 20 * myRobot->xCoord, 20 + 20 * myRobot->yCoord, 20, 20);
    }
}

int randomInt(void)
{
    int num = (rand() % 10);
    return num;
}

void initMarker(struct marker *myMarker)
{
    //x and yofblock is the number of block from the top left
    myMarker->xOfMarker = randomInt();
    myMarker->yOfMarker = randomInt();
    background();
    setColour(gray);
    fillRect(20 + 20 * myMarker->xOfMarker, 20 + 20 * myMarker->yOfMarker, 20, 20);
}

void initObstacle(struct obstacle *myObstacle, struct marker*myMarker1, struct marker*myMarker2)
{
    myObstacle->xOfObstacle = randomInt();
    myObstacle->yOfObstacle = randomInt();
    if(myObstacle->xOfObstacle == myMarker1->xOfMarker && myObstacle->yOfObstacle == myMarker1->yOfMarker || myObstacle->xOfObstacle == myMarker2->xOfMarker && myObstacle->yOfObstacle == myMarker2->yOfMarker)
    {
        myObstacle->xOfObstacle = randomInt();
        myObstacle->yOfObstacle = randomInt();
    }
    background();
    setColour(black);
    fillRect(20 + 20 * myObstacle->xOfObstacle, 20 + 20 * myObstacle->yOfObstacle, 20, 20);
}

// void home(struct home *myHome)  this is the function to create home anywhere in the grid
// {
//     myHome->yOfHome = randomInt();
//     myHome->xOfHome = randomInt();
//     background();
//     setColour(blue);
//     fillRect(20 + 20 * myHome->xOfHome, 20 + 20 * myHome->yOfHome, 20, 20);
// }

void home(struct home *myHome)
{
    myHome->yOfHome = 0;
    myHome->xOfHome = 0;
    background();
    setColour(blue);
    fillRect(20 + 20 * myHome->xOfHome, 20 + 20 * myHome->yOfHome, 20, 20);
}

void vertical(void)
{
    background();
    for(int counter = 0; counter < 11; counter++)
    {
        drawLine(20 + 20 * counter, 20, 20 + 20 * counter, 220);
    }
}

void horizontal(void)
{
    background();
    for(int counter = 0; counter < 11; counter++)
    {
        drawLine(20, 20 + 20 * counter, 220, 20 + 20 * counter);
    }
}

void initGrid(void)
{
    vertical();
    horizontal();
}

int main(void)
{
    //There is an issue if the block is at the bottom row against the wall, it should cover all markers first before the bug appears tho
    srand(time(0));
    int numberOfMarkers = 2;
    struct marker myMarker1;
    struct marker myMarker2;
    struct obstacle myObstacle1;
    struct obstacle myObstacle2;
    struct obstacle myObstacle3;
    struct home myHome;
    struct robot myRobot;
    initGrid();
    initMarker(&myMarker1);
    initMarker(&myMarker2);
    initObstacle(&myObstacle1, &myMarker1, &myMarker2);
    initObstacle(&myObstacle2, &myMarker1, &myMarker2);
    initObstacle(&myObstacle3, &myMarker1, &myMarker2);
    home(&myHome);
    initRobot(&myRobot, myHome);
    sleep(100);
    int markerCollected = 0;
    while (markerCollected < numberOfMarkers)
    {
        while (myRobot.hasMarker == 0) 
        {
            if (myRobot.direction == 'e' || myRobot.direction == 'n')
            {
                if (myRobot.direction == 'n' && myRobot.xCoord == 9 && myRobot.yCoord == 0)
                {
                    left(&myRobot);
                    if (canMoveForward(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3) == 0) //for edge case where there is a block on x=8 and y=0, helps it escape from the corner.
                    {
                        left(&myRobot);
                        pushMovement(&myRobot);
                        forward(&myRobot);
                        sleep(100);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        right(&myRobot);
                        pushMovement(&myRobot);
                        forward(&myRobot);
                        sleep(100);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        pushMovement(&myRobot);
                        forward(&myRobot);
                        sleep(100);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        right(&myRobot);
                        pushMovement(&myRobot);
                        forward(&myRobot);
                        sleep(100);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        left(&myRobot);
                    }
                }
                if (canMoveForward(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3) == 1) 
                {
                    pushMovement(&myRobot);
                    forward(&myRobot);
                    sleep(100);
                } else {
                    if (myRobot.direction == 'e' && myRobot.xCoord == 9 && myRobot.yCoord == 9) 
                    { //handling edge cases where failed without this code
                            left(&myRobot);
                    } else if (myRobot.direction == 'e' && myRobot.yCoord == 9) { //handles the scenario where there is a block on x = 8 and y = 9 while it is moving east on y = 8
                        left(&myRobot);
                    } else if (myRobot.direction == 'e' || myRobot.direction == 'n') {
                        if (canMoveRight(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3))
                        {
                            right(&myRobot);
                            pushMovement(&myRobot);
                            forward(&myRobot);
                            sleep(100);
                            right(&myRobot);
                            if (canMoveForward(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3) == 1) 
                            {
                                sleep(100);
                            } else if (canMoveForward(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3) == 0 && myRobot.yCoord == 9) {
                                right(&myRobot);
                            } else {
                                left(&myRobot);
                                pushMovement(&myRobot);
                                forward(&myRobot);
                                atMarker(&myRobot, &myMarker1);
                                atMarker(&myRobot, &myMarker2);
                                sleep(100);
                                right(&myRobot);
                            }
                    } else if (myRobot.xCoord == 9 && myRobot.direction == 'n'){ //handling edge case where there is a block on x = 9 and any value of y, while it is moving north. 
                                left(&myRobot);
                                pushMovement(&myRobot);
                                forward(&myRobot);
                                atMarker(&myRobot, &myMarker1);
                                atMarker(&myRobot, &myMarker2);
                                sleep(100);
                                right(&myRobot);
                                pushMovement(&myRobot);
                                forward(&myRobot);
                                atMarker(&myRobot, &myMarker1);
                                atMarker(&myRobot, &myMarker2);
                                sleep(100);
                                pushMovement(&myRobot);
                                forward(&myRobot);
                                atMarker(&myRobot, &myMarker1);
                                atMarker(&myRobot, &myMarker2);
                                sleep(100);
                                right(&myRobot);
                                pushMovement(&myRobot);
                                forward(&myRobot);
                                atMarker(&myRobot, &myMarker1);
                                atMarker(&myRobot, &myMarker2);
                                sleep(100);
                                left(&myRobot);
                    } else {
                        popMovement(&myRobot);
                        sleep(100);
                        right(&myRobot);
                        pushMovement(&myRobot);
                        forward(&myRobot);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        right(&myRobot);
                        if (canMoveForward(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3) == 1) 
                        {
                            sleep(100);
                        } else {
                            left(&myRobot);
                            pushMovement(&myRobot);
                            forward(&myRobot);
                            atMarker(&myRobot, &myMarker1);
                            atMarker(&myRobot, &myMarker2);
                            sleep(100);
                            right(&myRobot);
                        }
                    }
                }
            }
            atMarker(&myRobot, &myMarker1);
            atMarker(&myRobot, &myMarker2);
            } else {
                if (canMoveForward(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3) == 1) 
                {
                    pushMovement(&myRobot);
                    forward(&myRobot);
                    sleep(100);
                } else {
                    if (canMoveLeft(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3)) {
                        left(&myRobot);
                        pushMovement(&myRobot);
                        forward(&myRobot);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        sleep(100);
                        left(&myRobot);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        if (canMoveForward(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3) == 1) 
                        {
                            sleep(100);
                        } else {
                            right(&myRobot);
                            pushMovement(&myRobot);
                            forward(&myRobot);
                            atMarker(&myRobot, &myMarker1);
                            atMarker(&myRobot, &myMarker2);
                            left(&myRobot);
                            if (canMoveForward(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3) == 1) 
                            {
                                sleep(100);
                            } else {
                                right(&myRobot);
                                pushMovement(&myRobot);
                                forward(&myRobot);
                                atMarker(&myRobot, &myMarker1);
                                atMarker(&myRobot, &myMarker2);
                                sleep(100);
                                left(&myRobot);
                            }
                        }
                    } else if (myRobot.direction == 's' && myRobot.xCoord == 9 && myRobot.yCoord == 9) { //changes the direction to north
                        left(&myRobot);
                        left(&myRobot);
                    } else if (myRobot.xCoord == 9 && myRobot.direction == 's'){  //handling edge case where there is a block on x = 9 and any value of y, while it is moving south. 
                        right(&myRobot);
                        pushMovement(&myRobot);
                        forward(&myRobot);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        sleep(100);
                        left(&myRobot);
                        pushMovement(&myRobot);
                        forward(&myRobot);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        sleep(100);
                        pushMovement(&myRobot);
                        forward(&myRobot);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        sleep(100);
                        left(&myRobot);
                        pushMovement(&myRobot);
                        forward(&myRobot);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        sleep(100);
                        right(&myRobot);
                    } else if (myRobot.yCoord == 9) { //handling edge cases where failed without this code
                        myRobot.direction = 'n';
                    } else {
                        popMovement(&myRobot);
                        sleep(100);
                        left(&myRobot);
                        forward(&myRobot);
                        atMarker(&myRobot, &myMarker1);
                        atMarker(&myRobot, &myMarker2);
                        pushMovement(&myRobot);
                        left(&myRobot);
                        if (canMoveForward(&myRobot, &myObstacle1, &myObstacle2, &myObstacle3) == 1) 
                        {
                            sleep(100);
                        } else {
                            right(&myRobot);
                            pushMovement(&myRobot);
                            forward(&myRobot);
                            atMarker(&myRobot, &myMarker1);
                            atMarker(&myRobot, &myMarker2);
                            sleep(100);
                            left(&myRobot);
                        }
                    }
                }
            }
            atMarker(&myRobot, &myMarker1);
            atMarker(&myRobot, &myMarker2);
        }
        while (stackSize > 0) 
        {
            // Pop the last movement from the stack to retrace the steps
            popMovement(&myRobot);
            sleep(100);
            if (atHome(&myRobot, &myHome))
            {
                dropMarker(&myRobot);
                markerCollected++;
            }
        }
    }
}