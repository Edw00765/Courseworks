#include <stdio.h>

int factorial(int n)
{
  int counter = 1;
  int result = n;
  while (counter < n)
  {
    result = result * factorial(n - 1);
    return result;
  }
}

void checkStrong(int n)
{
  int num = n;
  int sum = 0;
  int factorialnum;
  int number = num;
  while (n != 0)
  {
    factorialnum = n%10;
    sum += factorial(factorialnum);
    n/=10;
  }
  if (sum == num)
  {
    printf("%d is a strong number \n", number);
  }
}

int main() 
{
  int first;
  int second;
  printf("Enter the first integer: \n");
  scanf("%d", &first);
  printf("Enter the second integer: \n");
  scanf("%d", &second);
  for (int difference = second - first; difference > 0; difference--)
  {
    checkStrong(first);
    first++;
  }
}