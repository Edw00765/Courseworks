#include <stdio.h>
#include <math.h>
int main(void)
{
    int a;
    int b;
    int c;
    printf("Type the length of side a: \n");
    scanf("%d", &a);
    printf("%d \n", a);
    printf("Type the length of side b: \n");
    scanf("%d", &b);
    printf("%d \n", b);
    printf("Type the length of side c: \n");
    scanf("%d", &c);
    printf("%d \n", c);
    
    int checkTriangle(void)
    {
        if (a + b < c || b + c < a || c + a < b)
        {
            return 0;
        } else {
            return 1;
        }
    }
    
    double calcS(int a, int b, int c)
    {
        printf("The values of a, b, c in calcS is %d, %d, %d, \n", a, b, c);
        double s = 10;
        s = (a + b + c) / 2;
        printf("The value of s is: %lf \n", s);
        return s;
    }

    double calcArea(float s)
    {
        printf("The values of a, b, c is %d, %d, %d, \n", a, b, c);
        double area = 10;
        area = sqrt(s*(s - a)*(s - b)*(s - c));
        printf("The area of the triangle is %lf", area);
    }

    if (checkTriangle() == 1)
    {
        calcArea(calcS(a, b, c));
    } else {
        printf("It is not a triangle");
    }

}