#include <stdio.h>
void checkLong(long num)
    {
        
    }

int main(void)
{
    long num;
    printf("What is the number: \n");
    scanf("%d", &num);
    printf("%d", num);
}