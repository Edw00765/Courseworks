#include <stdio.h>
void loop(int num, int power)
    {
        int result = num;
        for(int count = 1; count < power; count++)
        {
            result = result * num;
        }
        printf("The result from loop is:%d \n", result);
    }

int recursion(int num, int power)
{
    int result = num;
    if (power > 1)
    {
        return result * recursion(num, power - 1);
    } else {
        return result;
    }
}

int main(void)
{
    int num;
    int power;
    printf("What is the integer: \n");
    scanf("%d", &num);
    printf("What is the power: \n");
    scanf("%d", &power);
    int value = recursion(num, power);
    printf("The value from recursion is: %d \n", value);
    loop(num, power);
}