#include <stdio.h>
void palindrome(int num)
    {
        long reversed = 0;
        long remainder = 0;
        long original = num;
        while (num != 0)
        {
            int remainder = num % 10;
            reversed = reversed * 10 + remainder;
            num /= 10;
        }
        if (reversed == original)
        {
            printf("This number is a palindrome");
        } else {
            printf("This number is not a palindrome");
        }
    }

int main(void)
{
    long num;
    printf("What is the number: \n");
    scanf("%d", &num);
    palindrome(num);
}