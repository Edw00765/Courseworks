#include <stdio.h>
void multiplier(int num1, int num2)
    {
        int result = num1;
        for (int difference = num2 - num1; difference > 0; difference--)
        {
            result = result * (num1 + difference);
        }
        printf("%d" , result);
    }

int main(void)
{
    int num1;
    int num2;
    printf("What is the first number: \n");
    scanf("%d", &num1);
    printf("What is the second number: \n");
    scanf("%d", &num2);
    multiplier(num1, num2);
}