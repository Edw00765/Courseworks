#include <stdio.h>

void isPrime(int n)
{
  int i;
  int flag = 0;
  if (n == 0 || n == 1)
    flag = 1;
  for (i = 2; i <= n / 2 + 1; ++i) 
  {
    if (n % i == 0) {
      flag = 1;
      break;
    }
    if ((n+2) % i == 0) {
      flag = 1;
      break;
    }
  }
  if (flag == 0)
  {
    int prime = n;
    int twin = n + 2;
    printf("%d, %d \n", prime, twin);
  }
}

int main() 
{
  int n;
  int n2;
  int i;
  printf("Enter the first integer: \n");
  scanf("%d", &n);
  printf("Enter the next integer: \n");
  scanf("%d", &n2);
  for (int difference = n2 - n; difference > 0; difference--)
  {
    isPrime(n);
    n = n+1;
  }
}