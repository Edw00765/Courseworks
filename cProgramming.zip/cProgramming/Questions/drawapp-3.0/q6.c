#include <stdio.h>
#include "graphics.h"
int main(void)
{
 drawOval(200, 50, 100, 100);
 drawRect(215, 65, 70, 70);
 return 0;
}
