#include <stdio.h>

int main(void)
{
    int row = 0;
    while (row < 4)
    {
        int column = 0;
        while (column < 5)
        {
            if (row > 0 && row < 3 && column > 0 && column <4)
            {
                printf(" ");
            }
            else
            {
                printf("*");
            }
            column++;
        }
    printf("\n");
    row++;
    }
    return 0;
}