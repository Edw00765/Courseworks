#include <stdio.h>

int main(void)
{
    for(int row = 1; row < 7; row++)
    {
        if (row % 2 == 1)
        {
            for (int column = 1; column < 7; column++)
            {
                if (column % 2 == 1)
                {
                    printf("*");
                } else {
                    printf("#");
                }
            }
        } else {
            for (int column = 1; column < 7; column++)
            {
                if (column % 2 == 1)
                {
                    printf("#");
                } else {
                    printf("*");
                }
            }
        }
        printf("\n");
    }
}