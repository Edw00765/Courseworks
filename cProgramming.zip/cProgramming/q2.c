// Written by <Edward Tandanu 10/10/2023>
// This program displays my name.
#include <stdio.h>
#include <string.h>
int main(void)
{
 char name[] = "Dept. of Computer Science";
 char address1[] = "Malet Place Engineering Building";
 printf("The location of the %s is %s\n", name, address1);
 return 0;
}