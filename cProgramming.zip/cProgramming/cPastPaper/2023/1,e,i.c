#include <stdio.h>

typedef struct Node{
    int num;
    double decimal;
    char* pointer;
} Node;

Node* newNode(int num, double decimal, char* pointer){
    Node* node = (Node*)malloc(sizeof(Node));
    node -> num = num;
    node -> decimal = decimal;
    node -> pointer = pointer;
    return node;
};

char** pointerInList(Node* node){
    char** listOfPointers = (char**)malloc(sizeof(char*) * 100);
    if (listOfPointers == NULL) {
        return NULL;
    }

    int index = 0;

    while (node != NULL && index < 100){
        listOfPointers[index] = node -> pointer;
        index++;
        node = node -> pointer;
    }
    return listOfPointers;
}