#include <stdlib.h>

char* toString(int num) {
    char* str;
    int i = 0;
    int remaining = num;

    // Determine the length of the string
    int len = (num == 0) ? 1 : 0;
    while (remaining != 0) {
        remaining /= 10;
        len++;
    }

    // Allocate memory for the string
    str = (char*)malloc((len + 1) * sizeof(char));  // Plus one for the null terminator
    if (str == NULL) {
        // Handle memory allocation failure
        return NULL;
    }

    // Convert each digit to a character and store in the string
    i = 0;
    remaining = num;
    if (num < 0) {
        str[i++] = '-';
        remaining *= -1;
    }
    if (num == 0) {
        str[i++] = '0';
    }
    while (remaining != 0) {
        int digit = remaining % 10;
        str[i++] = digit + '0'; // need to add '0' in the end to convert to ascii
        remaining /= 10;
    }

    // Null-terminate the string
    str[i] = '\0';

    // Reverse the string
    // because the digits get reversed during our functions
    int j;
    for (j = 0; j < i / 2; j++) {
        char temp = str[j];
        str[j] = str[i - j - 1];
        str[i - j - 1] = temp;
    }

    return str;
}