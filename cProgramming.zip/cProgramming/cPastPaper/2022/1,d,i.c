#include <stdio.h>
int numberOfDigits(int num){
    int digitNum = 0;
    if (num < 0){
        num = num * -1;
    }
    do {
        num = num / 10;
        digitNum++;
    } while (num >= 1);
    return digitNum;
}

int main(){
    int num = numberOfDigits(123);
    printf("%d", num);
    return 0;
}

